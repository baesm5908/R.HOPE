"""Workflow/report helpers. No database, writes, network calls or text logging."""
from datetime import datetime
from zoneinfo import ZoneInfo
import uuid
from analyzer import InputError, analyze_text, parse_user_input

MAX_CHARS = 10000
QUESTIONS = [
    '최근 가장 마음에 걸리는 일은 무엇인가요?',
    '그 일을 떠올릴 때 어떤 생각이나 감정이 드나요?',
    '최근 수면, 일상, 대인관계에 변화가 있었나요?',
    '힘들 때 어떤 방법으로 대처하거나 누구에게 도움을 구하나요?',
]
SOURCES = {'direct': '직접 글 작성', 'guided': '가이드형 사전대화', 'transcript': '상담 기록 분석'}
SELF_EXAMPLE = ('최근 과제가 쌓여서 마음이 복잡하고 자꾸 걱정이 들어요. '
                '밤에는 생각이 많아 잠이 잘 오지 않고 아침에 피곤해요. '
                '친구에게 이야기하고 산책을 하며 조금씩 정리해보려 해요.')
TRANSCRIPT_EXAMPLE = ('상담사: 최근 가장 마음에 걸리는 일은 무엇인가요?\n'
                      '내담자: 과제가 쌓여서 걱정이 많고 잠도 잘 오지 않아요.\n'
                      '상담사: 힘들 때 어떻게 지내시나요?\n'
                      '내담자: 혼자 해결하려다 어려워서 친구와 이야기해보려고 해요.')


def guided_text(answers):
    if len(answers) != len(QUESTIONS):
        raise InputError('네 질문의 답변 상태를 확인해 주세요.')
    return '\n'.join(a.strip() for a in answers if a.strip())


def validate_input(text, source, consent=False):
    if source not in SOURCES:
        raise InputError('지원하지 않는 입력 유형입니다.')
    if not isinstance(text, str) or len(text.strip()) < 20:
        raise InputError('분석할 내용을 최소 20자 이상 입력해 주세요.')
    if len(text) > MAX_CHARS:
        raise InputError('입력은 최대 10,000자까지 가능합니다.')
    if source == 'transcript' and not consent:
        raise InputError('당사자 동의와 비식별화 확인이 필요합니다.')
    mode = '상담사 입력' if source == 'transcript' else '본인 직접 입력'
    parts = parse_user_input(text, mode)
    if not parts or sum(len(p) for p in parts) < 20:
        raise InputError('8자 이상인 분석 발화를 합쳐 20자 이상 작성해 주세요. 상담 기록은 내담자: 형식을 확인해 주세요.')
    return mode, parts


def run_analysis(text, source, consent=False):
    mode, parts = validate_input(text, source, consent)
    result = analyze_text(text, mode)
    result.update(source=source, analysis_version='rhope-baseline-v1',
                  id=uuid.uuid4().hex[:12],
                  created_at=datetime.now(ZoneInfo('Asia/Seoul')).isoformat(timespec='seconds'),
                  excerpts=parts[:5],
                  patterns={'scope': '이번 입력 전체', 'labels': [s['label'] for s in result['signals']]})
    return result


def create_report(result, discussion='', review=None):
    lines = ['# R.HOPE · 상담 준비 보고서', '',
             f"기록 번호: {result['id']}", f"생성 일시 (한국 시간): {result['created_at']}",
             f"입력 방식: {SOURCES[result['source']]} / {result['mode']}",
             f"분석 문장/발화 수: {result['analyzed_units']}",
             f"탐지된 요인 종류: {len(result['signals'])}",
             '', '연구·시연용 프로토타입. 진단, 치료 또는 개인 위험도 판정이 아닙니다.',
             '', '## 원문 기반 정리', '사용자 또는 내담자 원문의 앞 5개 분석 단위를 발췌했습니다. 생성형 AI 요약이 아닙니다.']
    for i, excerpt in enumerate(result['excerpts'], 1):
        lines += ['', f'{i}. {excerpt}']
    lines += ['', '## 관련 표현과 근거', '단위: 관련 표현이 탐지된 문장/발화 수. 심각도나 확률이 아닙니다.']
    for signal in result['signals']:
        lines += ['', f"### {signal['label']} · {signal['count']}개"]
        lines += [f'- {e}' for e in signal['evidence']]
    if not result['signals']:
        lines += ['현재 모델이 표시할 관련 표현을 찾지 못했습니다. 문제가 없다는 뜻은 아닙니다.']
    lines += ['', '## 이번 입력에서 함께 탐지된 요인',
              ' · '.join(result['patterns']['labels']) if len(result['signals']) > 1 else '복수 요인 조합이 탐지되지 않았습니다.',
              '같은 입력 전체에서의 탐지입니다. 같은 발화의 동시출현, 데이터셋 통계나 인과관계가 아닙니다.',
              '', '## 추가로 대화하고 싶은 내용', discussion.strip() or '작성하지 않음',
              '', '## 모델 한계', result['limitations'],
              '오탐과 누락이 있으며 라벨 양수의 공식 의미, 의료적 타당성이 확인되지 않았습니다.',
              '사회적 지지·대처 방식 탐지가 부족 또는 부적절함을 뜻하지 않습니다. 최종 전문적 판단은 상담사가 합니다.']
    if review:
        lines += ['', '## 같은 세션의 시연용 검토', f"검토 선택: {review['status']}",
                  f"검토 메모: {review['note']}", '운영용 전문가 인증 또는 원격 전송 기록이 아닙니다.']
    lines += ['', '즉각적인 위험이 있다면 119/112 및 주변의 신뢰할 수 있는 사람·전문가에게 연락하세요.',
              '이 서비스는 실시간 위기 감지·구조를 제공하지 않습니다.']
    return '\n'.join(lines) + '\n'
