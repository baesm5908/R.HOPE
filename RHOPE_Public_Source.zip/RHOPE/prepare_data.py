"""R.HOPE: extract anonymized client paragraphs + annotated labels from nested ZIPs.

Usage: python prepare_data.py --training ../Training.zip --validation ../Validation.zip
The outputs contain verbatim counseling text. Keep them local/private.
"""
import argparse
import csv
import gzip
import hashlib
import io
import json
import math
import pathlib
import re
import zipfile
from collections import Counter

SIGNALS = {
    "stressful_event": "스트레스 사건",
    "negative_self-image": "부정적 자기인식",
    "coping": "대처 방식",
    "social_support": "사회적 지지",
    "loss_of_control": "통제력 상실",
    "depressive_mood": "우울 기분 관련 표현",
    "anxiety_mood": "불안 관련 표현",
    "craving": "갈망 관련 표현",
    "sleep_disturbance": "수면 문제",
    "avoidance": "회피 행동",
}


def extract(zip_path: pathlib.Path, dest: pathlib.Path):
    stats = Counter()
    dest.parent.mkdir(exist_ok=True, parents=True)
    with zipfile.ZipFile(zip_path) as outer, gzip.open(dest, 'wt', encoding='utf-8') as out:
        subfiles = [f for f in outer.namelist() if '/02.라벨링데이터/' in f and f.lower().endswith('.zip')]
        for sf in subfiles:
            with zipfile.ZipFile(io.BytesIO(outer.read(sf))) as inner:
                for fp in inner.namelist():
                    if not fp.lower().endswith('.json'):
                        continue
                    stats['all_json'] += 1
                    raw = inner.read(fp)
                    try:
                        obj = json.loads(raw.decode('utf-8-sig'))
                        if not isinstance(obj, dict) or not isinstance(obj.get('paragraph'), list):
                            raise ValueError('schema')
                    except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
                        stats['invalid_json'] += 1
                        print('invalid_json', hashlib.sha256((sf + '/' + fp).encode()).hexdigest()[:16])
                        continue
                    stats['valid_json'] += 1
                    subject = str(obj.get('id', obj.get('ID', ''))).strip().upper()
                    filename = str(obj.get('filename', pathlib.Path(fp).stem))
                    for idx, p in enumerate(obj.get('paragraph', [])):
                        if not isinstance(p, dict):
                            continue
                        if p.get('paragraph_speaker') != '내담자':
                            continue
                        content = re.sub(r'\s+', ' ', str(p.get('paragraph_text', ''))).strip()
                        if len(content) < 8:
                            continue
                        row = {
                            'subject_id': subject,
                            'session_id': filename,
                            'paragraph_idx': p.get('index', idx),
                            'text': content,
                        }
                        # Missing keys are *unlabeled*, never automatically negative.
                        for signal in SIGNALS:
                            val = p.get(signal)
                            numeric = isinstance(val, (int, float)) and not isinstance(val, bool) and math.isfinite(val)
                            row[signal] = (1 if val > 0 else 0) if numeric and val >= 0 else None
                        out.write(json.dumps(row, ensure_ascii=False) + '\n')
                        stats['client_paragraphs'] += 1
    return stats


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--training', default='../Training.zip')
    parser.add_argument('--validation', default='../Validation.zip')
    parser.add_argument('--output', default='data')
    args = parser.parse_args()
    p = pathlib.Path(args.output)
    for label, archive in [('train', args.training), ('validation', args.validation)]:
        stats = extract(pathlib.Path(archive), p / f'{label}.jsonl.gz')
        print(label, dict(stats), '=>', p / f'{label}.jsonl.gz')
    with (p / 'signal_names.json').open('w', encoding='utf-8') as f:
        json.dump(SIGNALS, f, ensure_ascii=False, indent=2)
