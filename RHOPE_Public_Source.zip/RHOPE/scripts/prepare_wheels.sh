#!/usr/bin/env bash
set -euo pipefail
repo_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_dir"
venv_dir="${RHOPE_VENV:-/workspace/rhope-venv}"
mkdir -p .wheelhouse
"$venv_dir/bin/python" -m pip download --cache-dir /workspace/.cache/rhope/pip --only-binary=:all: -r requirements.txt --dest .wheelhouse
"$venv_dir/bin/python" - <<'PY'
from pathlib import Path
import hashlib
root = Path('.wheelhouse')
files = sorted(root.glob('*.whl'))
(root / 'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in files))
print('Verified package downloads; wheel checksum manifest written:', len(files))
PY
