"""Build the team's source-based distribution; no source counseling/user records.

Python 3.12 is required on recipient machines. This is not a Windows EXE builder.
Output includes the supplied model: keep distribution within permitted use rights.
"""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def build(output):
    model = ROOT / 'artifacts/model.pkl'
    manifest = json.loads((ROOT / 'artifacts/model_manifest.json').read_text(encoding='utf-8'))
    if hashlib.sha256(model.read_bytes()).hexdigest() != manifest['sha256']:
        raise ValueError('Model checksum mismatch; distribution aborted.')
    files = {}
    for name in ('app.py', 'analyzer.py', 'service.py', 'prepare_data.py', 'prepare_research.py',
                 'train_model.py', 'validate_model.py', 'quick_test.py', 'requirements.txt',
                 'requirements-dev.txt', 'pytest.ini', '.gitignore', '.env.example',
                 'Dockerfile', 'Dockerfile.offline', 'Dockerfile.offline.dockerignore',
                 '.dockerignore', 'DATA_NOTES.md'):
        files[name] = ROOT / name
    files['DEVELOPER_README.md'] = ROOT / 'README.md'
    for directory in ('assets', 'docs', 'scripts', 'tests'):
        for path in (ROOT / directory).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                files[str(path.relative_to(ROOT))] = path
    files['.streamlit/config.toml'] = ROOT / '.streamlit/config.toml'
    for name in ('model.pkl', 'model_manifest.json', 'metrics.json',
                 'research_summary.json', 'validation_check.json'):
        path = ROOT / 'artifacts' / name
        if path.exists():
            files['artifacts/' + name] = path
    for path in (ROOT / 'distribution').iterdir():
        if path.is_file():
            files[path.name] = path
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, path in sorted(files.items()):
            z.write(path, 'RHOPE/' + name)
    with zipfile.ZipFile(output) as z:
        if z.testzip() is not None:
            raise ValueError('Archive integrity check failed.')
    checksum = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(output.suffix + '.sha256').write_text(checksum + '  ' + output.name + '\n')
    print('Distribution ZIP:', output)
    print('File count:', len(files), 'Size:', output.stat().st_size, 'bytes')
    print('SHA256:', checksum)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'dist/RHOPE_Distribution_v1.zip')
    build(parser.parse_args().output)
