#!/usr/bin/env bash
set -euo pipefail
repo_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_dir"
venv_dir="${RHOPE_VENV:-/workspace/rhope-venv}"
exec "$venv_dir/bin/python" -m streamlit run app.py --server.address 0.0.0.0 --server.port "${PORT:-8501}" --browser.gatherUsageStats false
