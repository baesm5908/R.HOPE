#!/usr/bin/env bash
set -euo pipefail
repo_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_dir"
venv_dir="${RHOPE_VENV:-/workspace/rhope-venv}"
python3 -m venv "$venv_dir"
"$venv_dir/bin/python" -m pip install --cache-dir /workspace/.cache/rhope/pip -r requirements.txt
"$venv_dir/bin/python" -m pip check
"$venv_dir/bin/python" quick_test.py
