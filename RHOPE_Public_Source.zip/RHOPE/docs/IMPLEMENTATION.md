# R.HOPE 구현·검증 기록

작업일: 2026-10-08 (Asia/Seoul). 요구사항은 사용자가 제공한 최종 통합 마스터 프롬프트 전체를 읽고 반영했습니다.

## 시작 시점의 실제 현황

| 대상 | 코드 근거 | 조치 |
|---|---|---|
| Git 저장소 `baesm5908/R.HOPE` | README.md만 존재. 시작 상태 clean | 기존 변경을 삭제하지 않고 코드 추가 |
| 첨부 MVP | app.py, analyzer.py, prepare_data.py, train_model.py, quick_test.py | 기존 Streamlit·Python 유지·확장 |
| 기존 UI | app.py의 직접 입력·상담사 입력·결과·근거 | 해당 기능 유지, 5개 화면과 가이드·보고서 추가 |
| 모델 | model.pkl, 문자 TF-IDF, 10개 SGDClassifier | 원본 재사용, checksum·버전·클래스 허용 목록 검증 |
| 지표 | artifacts/metrics.json, 10개 요인 | 바이트 단위로 원본 보존, 실제 Validation 재현 |
| Training | 첨부 있으나 전송 도구의 32MiB 제한 | 실제 데이터 집계·ID 중복 검증 미완료 고지 |
| Validation | 중첩 ZIP의 라벨 JSON | 176개·174개 정상·2개 오류·16,700발화 직접 확인 |

기존 앱에는 URL 라우팅이나 별도 프론트/API가 없었습니다. 현재 `?page=home/story/result/counselor/research`로 이동합니다. Streamlit을 React로 바꾸지 않았고 피클을 브라우저에 전달하지 않습니다.

## 변경 파일

| 파일 | 역할 |
|---|---|
| app.py | 5화면·3모드, 원문 근거, 실제 그래프·다운로드, 동의·메모·철회·세션 삭제 |
| analyzer.py | 기존 분석 계약, 여러 줄 발화·화자 검증, 원문 유지, 모델 캐시와 검증 |
| service.py | 입력 검증, 답변만 결합, 결과 메타데이터·원문 발췌 보고서 |
| prepare_data.py | 기존 파이프라인 재사용, 결측 보존·형식 오류 해시 ID 로그 |
| train_model.py | 기존 학습 설정 유지, 전체 분할 ID 검증 후 표본추출, 새 manifest 생성 |
| prepare_research.py | 실제 ZIP 익명 집계, Training만 세션 동시출현, 쌍별 분모·최소 표본 |
| validate_model.py | Validation 재평가, 기존 지표 수정 없이 일치 여부 확인 |
| artifacts/metrics.json | 원본 유지, 공개 가능한 익명 검증 지표 |
| artifacts/model_manifest.json | 첨부 모델 checksum·학습 sklearn 버전·권한 미확인 명시 |
| assets/style.html | 한국어 Teal/Mint 토큰, 모바일·포커스·카드·히어로 SVG |
| .streamlit/config.toml | 테마, 통계 수집 끄기, CORS/XSRF 보호 유지 |
| tests/ | 실제 모델·계약·입력·연구·보고서·AppTest·Playwright 검증 |
| scripts/setup.sh, scripts/run.sh | 반복 설치·모델 확인·서버 시작 (prepare_wheels.sh는 검증된 오프라인 빌드 패키지 준비) |
| Dockerfile, Dockerfile.offline, .dockerignore, docs/nginx.conf.example | 모델/원문 제외 컨테이너·헬스체크·WebSocket 프록시 준비 |
| README.md, DATA_NOTES.md, .env.example, .gitignore | 실행·한계·권한·환경 변수·민감파일 제외 |

`artifacts/model.pkl`, `research_summary.json`, `validation_check.json`, `data/validation.jsonl.gz`, `test-results/`는 로컬 산출물이며 Git 추적에서 제외했습니다. 원본 상담 텍스트는 프론트 연구 화면·CSV·차트에 전달하지 않습니다.

## 수락 기준 검증

| 기준 | 결과·근거 |
|---|---|
| 홈 3모드 이동·모바일 | AppTest 및 Chromium 1440px/390px, 가로 넘침 없음 |
| 20자 이상 실제 모델 분석 | 기존 quick_test와 실제 UI·모델 단위 테스트 통과 |
| 가이드 질문 제외 | 4답변 전달·편집·이전·건너뛰기·초기화 테스트 통과 |
| 내담자만 분석 | 여러 줄 발화와 화자 오류·상담사 0근거 테스트 통과 |
| 입력·모델·통계 오류 | 빈/짧은/과다/화자 없음/동의 없음/모델 없음/무결성 오류/지표 없음 분기 통과 |
| 탐지 없음 | 실제 out-of-vocabulary 입력 0탐지, '문제가 없다는 뜻 아님' 보고서 분기 검증 |
| 다운로드 일치 | 브라우저의 Markdown/JSON/검토 보고서와 모델 count·근거 일치 확인 |
| 상담사 세션 격리 | 별도 브라우저 컨텍스트에서 동의·보고서 접근 불가, 메모 저장·철회 통과 |
| 실제 연구 수치 | Validation 실제 집계, 10요인 재평가 원본 지표 모두 일치 |
| Training 조합 통계 | 파이프라인·쌍별 분모를 합성 자료로 검증. 실제 Training 결과는 미실행 |
| 개인정보·XSS | 원문/모델/사용자 산출물 ignore 확인, 사용자 텍스트 st.text 사용, 실제 script 실행 없음 |
| 기존 계약·핵심 동작 | 기존 필드·함수와 quick_test 유지·통과 |
| 외부 URL | 배포 미완료. 호스팅 계정·도메인 및 배포 권한 검토 필요 |

현재 자동 테스트 **35개 통과**, 기존 스모크 테스트 2개 모드 통과, Chromium 종단 검증 통과. `bash scripts/setup.sh` 반복 실행, `bash scripts/run.sh` 별도 포트 시작, HTTP 상태 응답 확인을 수행했습니다. 오프라인 Docker 이미지 빌드·패키지 SHA-256 검증·비root 컨테이너의 실제 모델 추론 2모드·직접 입력 UI 분석·내부 상태 확인이 통과했습니다. 일반 온라인 Docker 빌드는 컨테이너 DNS/프록시 실패로 미검증이며, 외부 배포는 미완료입니다. 화면 캡처는 `test-results/`에 있으며 가상 입력만 사용했습니다.

검증 지표는 상담 전사 내담자 발화에 한정됩니다. Validation 재평가의 일치가 임상 검증 또는 독립적인 자유 글 성능 검증을 뜻하지 않습니다. Train/Validation 원본의 내담자 중복은 미검증이며 향후 학습 코드에서는 전체 ID 중복을 먼저 검사하도록 보강했습니다.

## 완료 범위·남은 작업

P0 사용자 흐름은 현재 작업 공간의 실제 모델로 연결됐습니다. P1의 Validation 자료 분포·모바일·메모·차트 JSON/CSV 내보내기 및 Training 집계 코드가 구현됐습니다. 실제 Training 동시출현·군별 Training 통계·분할 중복 검사는 자료 접근 후 실행해야 합니다.

자유 생성 LLM, KLUE-BERT, 운영용 로그인/RBAC/DB, 원격 기관 연결, 음성 입력·변화 추적은 구현하지 않았습니다. PDF 보고서는 선택 기능으로 미구현입니다. 데이터셋의 정확한 명칭·공식 라벨 가이드·데이터/모델 공개 이용권한은 미확인입니다.

팀 후속 업무는 README의 데이터·연구/모델/UI/통합·배포 역할에 정리했습니다.

## 공모전 10분 시연 동선

1. 0–1분: 홈의 연구 질문·'AI는 상담사를 대체하지 않는다' 설명.
2. 1–3분: 가상 사례의 직접 입력 → 실제 모델 분석 → 문장 수·원문 근거. 자유 글 미검증 고지 설명.
3. 3–4분: 입력 수정 또는 가이드 4질문, 사용자 답변만 모델에 전달함을 설명.
4. 4–5분: 가상 상담 기록으로 상담사 발화가 제외됨을 확인.
5. 5–7분: 보고서 다운로드 → 명시적 표시 동의 → 현재 세션 상담사 메모·수동 검토 선택 → 동의 철회.
6. 7–9분: 연구 페이지의 Validation 원본 집계·전체 F1, 낮은 성능·미라벨·Training 미분석 상태 공개.
7. 9–10분: 개인정보 처리 범위·원문 비공개·기록 삭제 시연, 공식 라벨 검증·자유 글 평가·배포 후속 과제.

시연에서 실제 상담자료를 입력하지 말고 앱에 포함된 가상 예시만 사용하세요.

## 재사용 클라우드 설정

`install_script`에 기존 체크아웃의 scripts/setup.sh 실행을, `start_skill`에 모델 확인·서버 재시작·준비 상태·테스트·개인정보·Training 미검증 지침을 저장했습니다. 초안 저장은 확인됐으며 게시하지 않았습니다. 환경 설정에서 검토·저장 후 환경을 게시하면 작업 공간 스냅샷을 재사용할 수 있습니다. 새 작업 복원은 아직 독립 검증하지 않았습니다.
