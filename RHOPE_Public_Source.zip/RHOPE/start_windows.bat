@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto install
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3.12 -m venv .venv
if errorlevel 1 goto failed
goto install
:usepython
python -c "import sys; assert sys.version_info[:2] == (3,12)" >nul 2>nul
if errorlevel 1 goto pythonmissing
python -m venv .venv
if errorlevel 1 goto failed
:install
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501 --server.headless false --browser.gatherUsageStats false
if errorlevel 1 goto failed
exit /b 0
:pythonmissing
echo Python 3.12 is required. Install from https://www.python.org/downloads/ and enable Add Python to PATH.
:failed
echo Startup failed. Please read README.md and the error shown above.
pause
exit /b 1
