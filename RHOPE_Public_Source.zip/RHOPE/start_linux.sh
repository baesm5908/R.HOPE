#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
trap 'echo "Startup failed. Read README.md and the error above."; read -r -p "Press Enter to close..." _rhope_close' ERR
if [ ! -x .venv/bin/python ]; then
    if command -v python3.12 >/dev/null 2>&1; then
        python3.12 -m venv .venv
    else
        python3 -c 'import sys; assert sys.version_info[:2] == (3,12), "Install Python 3.12 from python.org"'
        python3 -m venv .venv
    fi
fi
.venv/bin/python -m pip install -r requirements.txt
exec .venv/bin/python -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501 --server.headless false --browser.gatherUsageStats false
