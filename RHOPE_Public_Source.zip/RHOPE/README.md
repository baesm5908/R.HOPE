# R.HOPE 공개 소스 실행 패키지

Python 3.12 + Streamlit 프로젝트입니다. package.json은 없습니다.
압축을 전부 해제한 뒤 Windows CMD에서 아래 명령을 실행하세요.

```bat
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m streamlit run app.py --server.headless false
```

공개 재배포 권한이 확인되지 않은 model.pkl 및 연구 집계/지표는 이 공개 패키지에서 제외했습니다. 따라서 화면과 입력 흐름은 열리지만 실제 분석은 모델 연결 필요 상태입니다. 가짜 분석 결과로 대체하지 않습니다.

팀이 허가된 원본 MVP에서 model.pkl과 대응 model_manifest.json을 확보해 artifacts/에 설치하면 실제 분석을 실행할 수 있습니다. 허가된 metrics.json과 research_summary.json을 설치하면 연구 결과가 표시됩니다. quick_test.py는 모델 설치 후 실행하세요.

```bat
.venv\Scripts\python.exe quick_test.py
```

모델의 라이선스 및 공개 재배포 권한을 먼저 확인하세요. 원본 상담 데이터와 개인 기록은 포함하지 않았습니다. 진단 및 개인 위험도 판정 도구가 아닙니다.
