"""Private nested-ZIP research aggregation. Output contains counts, never source text.

Patterns use Training ONLY. Validation is descriptive/evaluation, never pattern mining.
Missing labels stay unlabeled. Unknown/negative label codes are not forced to negative.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import itertools
import json
import math
from pathlib import Path
import zipfile
from prepare_data import SIGNALS

GROUPS = {'001': '우울증', '002': '불안장애', '003': '중독', '004': '일반군'}


def label_value(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
        return 1 if value > 0 else (0 if value == 0 else None)
    return None


def scan_archive(path):
    sessions, errors, subjects, stats = [], [], set(), Counter()
    counts = {k: Counter() for k in SIGNALS}
    grouped = {g: {k: Counter() for k in SIGNALS} for g in [*GROUPS.values(), '미확인']}
    group_files, group_parsed = Counter(), Counter()
    with zipfile.ZipFile(path) as outer:
        nested = [f for f in outer.namelist() if '/02.라벨링데이터/' in f and f.lower().endswith('.zip')]
        for name in nested:
            group = next((v for k, v in GROUPS.items() if Path(name).name.startswith(('TL_' + k, 'VL_' + k))), '미확인')
            with zipfile.ZipFile(io.BytesIO(outer.read(name))) as inner:
                for fp in inner.namelist():
                    if not fp.lower().endswith('.json'):
                        continue
                    stats['total_sessions'] += 1
                    group_files[group] += 1
                    fid = hashlib.sha256((name + '/' + fp).encode()).hexdigest()[:16]
                    try:
                        obj = json.loads(inner.read(fp).decode('utf-8-sig'))
                        if not isinstance(obj, dict) or not isinstance(obj.get('paragraph'), list):
                            raise ValueError('schema')
                    except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
                        errors.append({'file_id': fid, 'reason': 'invalid_json_or_schema'})
                        stats['invalid_sessions'] += 1
                        continue
                    stats['parsed_sessions'] += 1
                    group_parsed[group] += 1
                    subject = str(obj.get('id', obj.get('ID', ''))).strip().upper()
                    if subject:
                        subjects.add(subject)
                    else:
                        stats['missing_subject_sessions'] += 1
                    eligible, positive = set(), set()
                    for p in obj['paragraph']:
                        if not isinstance(p, dict) or p.get('paragraph_speaker') != '내담자':
                            continue
                        text = ' '.join(str(p.get('paragraph_text', '')).split())
                        if len(text) < 8:
                            continue
                        stats['client_paragraphs'] += 1
                        for key in SIGNALS:
                            val = label_value(p.get(key))
                            state = 'unlabeled' if val is None else ('positive' if val else 'negative')
                            counts[key][state] += 1
                            grouped[group][key][state] += 1
                            if val is not None:
                                eligible.add(key)
                            if val == 1:
                                positive.add(key)
                    sessions.append({'eligible': eligible, 'positive': positive})
    labels = [{'key': k, 'label': name, **{s: counts[k][s] for s in ('positive', 'negative', 'unlabeled')}} for k, name in SIGNALS.items()]
    by_group = {g: [{'key': k, 'label': name, **{s: v[s] for s in ('positive', 'negative', 'unlabeled')}} for k, v in data.items()] for g, data in grouped.items() if group_files[g]}
    return {'stats': {k: stats[k] for k in ('total_sessions', 'parsed_sessions', 'invalid_sessions', 'client_paragraphs', 'missing_subject_sessions')},
            'group_sessions': dict(group_files), 'group_parsed': dict(group_parsed),
            'labels': labels, 'labels_by_group': by_group, 'errors': errors}, sessions, subjects


def patterns(sessions, minimum=5):
    matrix, associations = [], []
    for a, b in itertools.combinations(SIGNALS, 2):
        eligible = [s for s in sessions if {a, b} <= s['eligible']]
        n = len(eligible)
        na = sum(a in s['positive'] for s in eligible)
        nb = sum(b in s['positive'] for s in eligible)
        both = sum({a, b} <= s['positive'] for s in eligible)
        row = {'a': a, 'b': b, 'eligible_sessions': n, 'a_positive': na, 'b_positive': nb, 'both': both}
        matrix.append(row)
        if both >= minimum and n and na and nb:
            associations.append({**row, 'support': both / n, 'confidence_a_to_b': both / na,
                                 'confidence_b_to_a': both / nb, 'lift': both * n / (na * nb)})
    return {'unit': '세션', 'split': 'Training', 'minimum_both': minimum, 'matrix': matrix, 'associations': associations}


def build_summary(training=None, validation=None, minimum=5):
    result = {'schema_version': 1, 'generated_at': datetime.now(timezone.utc).isoformat(),
              'source': '사용자가 제공한 AI Hub 심리상담 자료 (정확한 원본 데이터셋명·공개 이용권한 미확인)',
              'filter': 'paragraph_speaker == 내담자, 공백 정규화 후 8자 이상',
              'label_definition': '양수=임시 양성, 0=음성, 결측/비수치/음수=미라벨. 공식 가이드 미확인; 별칭 통합 없음',
              'splits': {}, 'patterns': None,
              'overlap_check': {'status': 'unverified', 'reason': '두 분할 자료가 모두 필요합니다.'}}
    subjects = {}
    for split, path in [('Training', training), ('Validation', validation)]:
        if path:
            summary, sessions, ids = scan_archive(path)
            result['splits'][split] = summary
            subjects[split] = ids
            if split == 'Training':
                result['patterns'] = patterns(sessions, minimum)
    if len(subjects) == 2:
        missing = sum(s['stats']['missing_subject_sessions'] for s in result['splits'].values())
        result['overlap_check'] = {'status': 'incomplete_ids' if missing else 'checked',
                                  'overlapping_subject_count': len(subjects['Training'] & subjects['Validation']),
                                  'missing_subject_sessions': missing}
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--training', type=Path)
    p.add_argument('--validation', type=Path)
    p.add_argument('--output', type=Path, default=Path('artifacts/research_summary.json'))
    p.add_argument('--min-pair', type=int, default=5)
    args = p.parse_args()
    if not (args.training or args.validation):
        p.error('한 개 이상의 로컬 데이터 ZIP을 지정하세요.')
    summary = build_summary(args.training, args.validation, args.min_pair)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    for split, entry in summary['splits'].items():
        print(split, entry['stats'])
        for error in entry['errors']:
            print('parse_error', error['file_id'], error['reason'])
    print('Saved anonymous summary:', args.output)
