import io
import json
import zipfile
import pytest
from prepare_research import build_summary, label_value, patterns


def archive(tmp_path, name, objects):
    inner = io.BytesIO()
    with zipfile.ZipFile(inner, 'w') as z:
        for i, obj in enumerate(objects):
            z.writestr(f'private-id-{i}.json', obj if isinstance(obj, str) else json.dumps(obj))
    path = tmp_path / name
    with zipfile.ZipFile(path, 'w') as z:
        z.writestr('Validation/02.라벨링데이터/VL_001. 우울증_0001.zip', inner.getvalue())
    return path


def test_missing_non_numeric_not_negative():
    assert label_value(None) is None
    assert label_value('1') is None
    assert label_value(-1) is None
    assert label_value(float('nan')) is None
    assert label_value(0) == 0
    assert label_value(2) == 1


def test_session_counts_errors_privacy_and_overlap(tmp_path):
    obj = {'id': 'person-a', 'paragraph': [
        {'paragraph_speaker': '상담사', 'paragraph_text': '상담사 발화는 제외합니다.', 'coping': 1},
        {'paragraph_speaker': '내담자', 'paragraph_text': '비공개 원문 테스트 본문입니다.', 'coping': 1},
        {'paragraph_speaker': '내담자', 'paragraph_text': '두 번째 비공개 발화입니다.', 'coping': 0},
        {'paragraph_speaker': '내담자', 'paragraph_text': '짧음', 'coping': 1}]}
    path = archive(tmp_path, 'sample.zip', [obj, '{invalid'])
    summary = build_summary(training=path, validation=path)
    v = summary['splits']['Validation']
    assert v['stats']['total_sessions'] == 2
    assert v['stats']['parsed_sessions'] == 1
    assert v['stats']['invalid_sessions'] == 1
    assert v['stats']['client_paragraphs'] == 2
    coping = next(x for x in v['labels'] if x['key'] == 'coping')
    assert (coping['positive'], coping['negative'], coping['unlabeled']) == (1, 1, 0)
    missing = next(x for x in v['labels'] if x['key'] == 'sleep_disturbance')
    assert missing['unlabeled'] == 2 and missing['negative'] == 0
    encoded = json.dumps(summary, ensure_ascii=False)
    assert '비공개' not in encoded and 'person-a' not in encoded and 'private-id' not in encoded
    assert summary['overlap_check']['overlapping_subject_count'] == 1


def test_pairs_use_eligible_denominators():
    a, b = 'coping', 'social_support'
    sessions = [
        {'eligible': {a, b}, 'positive': {a, b}},
        {'eligible': {a, b}, 'positive': {a}},
        {'eligible': {a, b}, 'positive': {b}},
        {'eligible': {a}, 'positive': {a}}]
    result = patterns(sessions, 1)
    r = next(r for r in result['associations'] if r['a'] == a and r['b'] == b)
    assert r['eligible_sessions'] == 3 and r['both'] == 1
    assert r['support'] == pytest.approx(1/3)
    assert r['confidence_a_to_b'] == .5
    assert r['lift'] == pytest.approx(.75)


def test_validation_never_mined_for_patterns(tmp_path):
    path = archive(tmp_path, 'v.zip', [{'id': 'A', 'paragraph': []}])
    result = build_summary(validation=path)
    assert result['patterns'] is None
    assert result['overlap_check']['status'] == 'unverified'


def test_training_split_guard_prevents_leakage():
    from train_model import validate_subject_split
    with pytest.raises(ValueError, match='overlap'):
        validate_subject_split([{'subject_id': 'A'}], [{'subject_id': 'A'}])
    with pytest.raises(ValueError, match='Missing'):
        validate_subject_split([{'subject_id': ''}], [{'subject_id': 'B'}])
    validate_subject_split([{'subject_id': 'A'}], [{'subject_id': 'B'}])
