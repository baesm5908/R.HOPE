import io
import pickle
from pathlib import Path
import pytest
from analyzer import (analyze_text, parse_user_input, load_model, InputError,
                      ModelUnavailable, RestrictedModelUnpickler)
from service import SELF_EXAMPLE, TRANSCRIPT_EXAMPLE


def test_real_model_matches_supplied_smoke_case():
    result = analyze_text('요즘 잠이 잘 오지 않아서 아침에 피곤하고, 과제가 쌓여 고민이 많습니다. 친구와 이야기해 볼 생각이에요.', '본인 직접 입력')
    assert result['analyzed_units'] == 2
    assert any(s['key'] == 'sleep_disturbance' for s in result['signals'])
    assert set(result) == {'mode', 'analyzed_units', 'signals', 'limitations'}


@pytest.mark.parametrize('mode,text', [('본인 직접 입력', SELF_EXAMPLE), ('상담사 입력', TRANSCRIPT_EXAMPLE)])
def test_evidence_and_counts(mode, text):
    result = analyze_text(text, mode)
    units = parse_user_input(text, mode)
    for signal in result['signals']:
        assert 0 < signal['count'] <= len(units)
        assert 1 <= len(signal['evidence']) <= 3
        assert all(e in units and e in text for e in signal['evidence'])
        assert 'probability' not in signal


def test_multiline_transcript_is_exact_and_counselor_excluded():
    text = '상담사: 이 문장은 분석에서 제외해야 합니다.\n내담자： 최근 마음이 복잡합니다.\n밤에는 잠이 잘 오지 않아요.\n상담사: 저도 자주 밤에 잠을 못 잡니다.'
    parts = parse_user_input(text, '상담사 입력')
    assert parts == ['최근 마음이 복잡합니다.\n밤에는 잠이 잘 오지 않아요.']
    assert parts[0] in text
    result = analyze_text(text, '상담사 입력')
    assert all('저도' not in e for sig in result['signals'] for e in sig['evidence'])


@pytest.mark.parametrize('text', ['화자가 없는 상담 기록입니다. 잠을 못 잡니다.', '내담자: 최근 잠이 잘 오지 않아요.\n치료사: 새로운 화자입니다.'])
def test_ambiguous_speaker_rejected(text):
    with pytest.raises(InputError):
        parse_user_input(text, '상담사 입력')


def test_empty_analysis_and_model_absence(tmp_path):
    assert analyze_text('', '본인 직접 입력')['analyzed_units'] == 0
    with pytest.raises(ModelUnavailable):
        analyze_text(SELF_EXAMPLE, '본인 직접 입력', tmp_path / 'missing.pkl')


def test_bad_mode_and_oversize():
    with pytest.raises(InputError):
        analyze_text(SELF_EXAMPLE, 'diagnosis')
    with pytest.raises(InputError):
        analyze_text('가' * 10001, '본인 직접 입력')


def test_only_model_is_cached():
    assert load_model() is load_model()


def test_tampered_model_rejected(tmp_path, monkeypatch):
    model = tmp_path / 'model.pkl'
    model.write_bytes(b'not a verified model')
    manifest = Path('artifacts/model_manifest.json').resolve()
    monkeypatch.setenv('RHOPE_MODEL_MANIFEST', str(manifest))
    with pytest.raises(ModelUnavailable, match='무결성'):
        analyze_text(SELF_EXAMPLE, '본인 직접 입력', model)


def test_pickle_arbitrary_callable_rejected():
    with pytest.raises(pickle.UnpicklingError):
        RestrictedModelUnpickler(io.BytesIO(pickle.dumps(eval))).load()


def test_real_model_zero_signal_on_out_of_vocabulary_input():
    result = analyze_text('abcdefghij klmnopqrst uvwxyz', '본인 직접 입력')
    assert result['analyzed_units'] == 1
    assert result['signals'] == []
