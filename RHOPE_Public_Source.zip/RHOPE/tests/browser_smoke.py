"""Run against a running local app: python tests/browser_smoke.py.
Uses synthetic data only. No browser results or user data are committed.
"""
import json
import os
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

BASE = os.getenv('RHOPE_TEST_URL', 'http://127.0.0.1:8501')
OUT = Path('test-results')
OUT.mkdir(exist_ok=True)


def click(page, text):
    page.get_by_role('button', name=text, exact=True).click()


def wait_page(page, title):
    expect(page.get_by_role('heading', name=title, exact=True)).to_be_visible()
    expect(page.locator('[data-testid="stException"]')).to_have_count(0)


def no_overflow(page):
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'viewport overflow'
    assert page.evaluate('Array.from(document.querySelectorAll(".stMainBlockContainer")).every(e=>e.scrollWidth<=e.clientWidth)'), 'main overflow'


def get_download(page, label):
    with page.expect_download() as pending:
        click(page, label)
    download = pending.value
    path = OUT / download.suggested_filename
    download.save_as(path)
    return path.read_text(encoding='utf-8')


with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.getenv('CHROMIUM_PATH', '/usr/bin/chromium'), headless=True, args=['--no-sandbox'])
    errors = []
    context = browser.new_context(viewport={'width':1440,'height':1000}, accept_downloads=True)
    page = context.new_page()
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto(BASE)
    expect(page.get_by_role('button', name='직접 작성 시작 →', exact=True)).to_be_visible()
    no_overflow(page)
    page.screenshot(path=str(OUT/'home-desktop.png'))
    click(page, '직접 작성 시작 →')
    wait_page(page, '마음 이야기')
    click(page, '심리 신호 살펴보기 →')
    expect(page.get_by_text('분석할 내용을 최소 20자 이상 입력해 주세요.', exact=True)).to_be_visible()
    click(page, '가상 예시로 체험하기')
    click(page, '심리 신호 살펴보기 →')
    wait_page(page, '마음의 신호 살펴보기')
    report = get_download(page, '보고서 다운로드 (.md)')
    assert get_download(page, '보고서 다운로드 (.txt)') == report
    exported = json.loads(get_download(page, '결과 내보내기 (.json)'))
    assert exported['source'] == 'direct' and exported['signals']
    for sig in exported['signals']:
        assert f"{sig['label']} · {sig['count']}개" in report
        assert all(e in report for e in sig['evidence'])
    click(page, '동의 후 상담사 미리보기 열기')
    expect(page.get_by_text('미리보기를 열려면 표시 동의가 필요합니다.', exact=True)).to_be_visible()
    page.locator('[data-testid="stCheckbox"] label').click()
    click(page, '동의 후 상담사 미리보기 열기')
    wait_page(page, '상담사 검토 미리보기')
    page.get_by_role('textbox', name='검토 메모', exact=True).fill('가상 사례 검토: 수면에 대해 추가로 논의합니다.')
    click(page, '검토 저장 / 수정')
    expect(page.get_by_text('현재 세션 메모리에 검토 내용을 저장했습니다.', exact=True)).to_be_visible()
    reviewed = get_download(page, '검토 포함 보고서 다운로드')
    assert '수면에 대해 추가로 논의합니다.' in reviewed
    isolated = browser.new_context()
    outsider = isolated.new_page()
    outsider.goto(BASE + '/?page=counselor')
    wait_page(outsider, '상담사 검토 미리보기')
    expect(outsider.get_by_text('표시 동의를 받은 현재 세션의 보고서가 없습니다. 분석 결과에서 동의 후 미리보기를 열어 주세요.', exact=True)).to_be_visible()
    assert '수면에 대해 추가로 논의합니다.' not in outsider.locator('body').inner_text()
    isolated.close()
    click(page, '미리보기 동의 철회 · 검토 초기화')
    expect(page.get_by_text('표시 동의를 받은 현재 세션의 보고서가 없습니다. 분석 결과에서 동의 후 미리보기를 열어 주세요.', exact=True)).to_be_visible()
    click(page, '모든 기록 지우기')
    click(page, '가이드 대화 시작 →')
    for i in range(4):
        page.get_by_role('textbox', name='나의 답변', exact=True).fill('가상 답변입니다. 최근 잠이 잘 오지 않아 피곤하고 친구에게 고민을 이야기하고 있어요.')
        click(page, '답변 저장 · 다음 →' if i<3 else '답변 정리하기 →')
    click(page, '답변에서 심리 신호 살펴보기')
    wait_page(page, '마음의 신호 살펴보기')
    guided = json.loads(get_download(page, '결과 내보내기 (.json)'))
    assert guided['source'] == 'guided'
    assert all('최근 가장 마음에 걸리는 일은 무엇인가요?' not in e for sig in guided['signals'] for e in sig['evidence'])
    click(page, '모든 기록 지우기')
    click(page, '상담 기록 입력 →')
    click(page, '가상 예시로 체험하기')
    click(page, '심리 신호 살펴보기 →')
    expect(page.get_by_text('당사자 동의와 비식별화 확인이 필요합니다.', exact=True)).to_be_visible()
    page.locator('[data-testid="stCheckbox"] label').click()
    page.get_by_role('textbox').fill('상담사: 이 발화는 절대로 근거에 포함하지 않습니다.\n내담자: 최근 걱정이 많고 잠이 잘 오지 않아 피곤합니다.\n친구에게 고민을 이야기하고 있어요.\n상담사: 이 문장도 분석에서 제외합니다.')
    click(page, '심리 신호 살펴보기 →')
    wait_page(page, '마음의 신호 살펴보기')
    transcript = json.loads(get_download(page, '결과 내보내기 (.json)'))
    assert transcript['mode'] == '상담사 입력' and transcript['analyzed_units'] == 1
    assert all('이 발화는' not in e and '이 문장도' not in e for sig in transcript['signals'] for e in sig['evidence'])
    click(page, '연구 결과')
    wait_page(page, '데이터와 모델 연구')
    page.get_by_role('tab', name='모델 검증', exact=True).click()
    metrics = json.loads(get_download(page, '검증 지표 JSON 다운로드'))
    assert len(metrics['labels']) == 10
    page.screenshot(path=str(OUT/'research-desktop.png'))
    page.get_by_role('tab', name='동시출현 연구', exact=True).click()
    expect(page.get_by_text('아직 분석되지 않음 · Training ZIP이 필요합니다. Validation으로 패턴을 탐색하거나 가상의 Lift 수치를 만들지 않습니다.', exact=True)).to_be_visible()
    context.close()

    mobile = browser.new_context(viewport={'width':390,'height':844}, is_mobile=True, device_scale_factor=1, accept_downloads=True)
    mp = mobile.new_page()
    mp.goto(BASE)
    expect(mp.get_by_role('button', name='홈', exact=True)).to_be_visible()
    no_overflow(mp)
    mp.screenshot(path=str(OUT/'home-mobile.png'))
    click(mp, '직접 작성 시작 →')
    wait_page(mp, '마음 이야기')
    no_overflow(mp)
    dialogs=[]
    mp.on('dialog', lambda dialog: (dialogs.append(dialog.message), dialog.dismiss()))
    mp.get_by_role('textbox').fill('<script>alert(1)</script> 최근 잠이 잘 오지 않아서 피곤하고 친구에게 이야기하고 있습니다.')
    click(mp, '심리 신호 살펴보기 →')
    wait_page(mp, '마음의 신호 살펴보기')
    no_overflow(mp)
    assert not dialogs
    mp.screenshot(path=str(OUT/'result-mobile.png'))
    click(mp, '모든 기록 지우기')
    expect(mp.get_by_role('button', name='직접 작성 시작 →', exact=True)).to_be_visible()
    click(mp, '분석 결과')
    expect(mp.get_by_text('아직 분석한 이야기가 없어요. 먼저 마음 이야기를 작성해 주세요.', exact=True)).to_be_visible()
    click(mp, '연구 결과')
    wait_page(mp, '데이터와 모델 연구')
    no_overflow(mp)
    mp.get_by_role('tab', name='모델 검증', exact=True).click()
    no_overflow(mp)
    mobile.close()
    assert not errors, errors
    browser.close()
    print('Browser PASS: desktop/mobile, direct/guided/transcript, consent, Markdown/JSON/review downloads, session isolation, research, clearing, XSS, overflow.')
