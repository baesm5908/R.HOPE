from streamlit.testing.v1 import AppTest
from service import SELF_EXAMPLE


def button(app, label):
    return next(b for b in app.button if b.label == label)


def test_home_direct_result_share_review_clear():
    app = AppTest.from_file('app.py', default_timeout=20).run()
    assert not app.exception
    button(app, '직접 작성 시작 →').click().run()
    assert not app.exception
    app.text_area[0].input(SELF_EXAMPLE).run()
    button(app, '심리 신호 살펴보기 →').click().run()
    assert not app.exception
    assert app.session_state['result']['analyzed_units'] > 0
    button(app, '동의 후 상담사 미리보기 열기').click().run()
    assert app.warning
    app.checkbox[0].check().run()
    button(app, '동의 후 상담사 미리보기 열기').click().run()
    assert not app.exception
    app.text_area[0].input('가상 사례의 검토 메모입니다.')
    button(app, '검토 저장 / 수정').click().run()
    assert not app.exception
    assert app.session_state['review']['note'] == '가상 사례의 검토 메모입니다.'
    app.selectbox[0].select('추적 확인')
    app.text_area[0].input('수정된 가상 검토 메모입니다.')
    button(app, '검토 저장 / 수정').click().run()
    assert app.session_state['review'] == {'status': '추적 확인', 'note': '수정된 가상 검토 메모입니다.'}
    button(app, '모든 기록 지우기').click().run()
    assert not app.exception
    assert app.session_state['result'] is None


def test_guided_four_answers_no_questions():
    app = AppTest.from_file('app.py', default_timeout=20).run()
    button(app, '가이드 대화 시작 →').click().run()
    for i in range(4):
        app.text_area[0].input(SELF_EXAMPLE).run()
        label = '답변 저장 · 다음 →' if i < 3 else '답변 정리하기 →'
        button(app, label).click().run()
    button(app, '답변에서 심리 신호 살펴보기').click().run()
    assert not app.exception
    result = app.session_state['result']
    assert result['source'] == 'guided'
    assert all('최근 가장 마음에 걸리는' not in e for sig in result['signals'] for e in sig['evidence'])


def test_research_and_new_session_privacy():
    app = AppTest.from_file('app.py', default_timeout=20).run()
    button(app, '연구 결과').click().run()
    assert not app.exception
    assert len(app.dataframe) >= 4
    button(app, '상담사 검토').click().run()
    assert app.warning
    assert app.session_state['shared_id'] is None


def test_missing_model_and_stats_are_visible_not_fake(monkeypatch, tmp_path):
    monkeypatch.setenv('RHOPE_MODEL_PATH', str(tmp_path/'missing.pkl'))
    monkeypatch.setenv('RHOPE_METRICS_PATH', str(tmp_path/'metrics.json'))
    monkeypatch.setenv('RHOPE_RESEARCH_PATH', str(tmp_path/'research.json'))
    app = AppTest.from_file('app.py', default_timeout=20).run()
    button(app, '직접 작성 시작 →').click().run()
    assert app.error and not app.exception
    app.text_area[0].input(SELF_EXAMPLE).run()
    button(app, '심리 신호 살펴보기 →').click().run()
    assert app.error and app.session_state['result'] is None
    button(app, '연구 결과').click().run()
    assert app.warning and not app.exception
    assert not app.dataframe


def test_guided_previous_skip_edit_and_reset():
    app = AppTest.from_file('app.py', default_timeout=20).run()
    button(app, '가이드 대화 시작 →').click().run()
    app.text_area[0].input(SELF_EXAMPLE).run()
    button(app, '답변 저장 · 다음 →').click().run()
    button(app, '← 이전 질문').click().run()
    assert app.text_area[0].value == SELF_EXAMPLE
    button(app, '답변 저장 · 다음 →').click().run()
    button(app, '건너뛰기').click().run()
    assert app.session_state['answers'][1] == ''
    next(b for b in app.button if b.key == 'edit_answer_0').click().run()
    assert app.text_area[0].value == SELF_EXAMPLE
    button(app, '처음부터 다시하기').click().run()
    assert app.session_state['answers'] == ['', '', '', '']
    assert app.text_area[0].value == ''
    assert not app.exception


def test_navigation_preserves_direct_draft():
    app = AppTest.from_file('app.py', default_timeout=20).run()
    button(app, '직접 작성 시작 →').click().run()
    app.text_area[0].input(SELF_EXAMPLE).run()
    button(app, '연구 결과').click().run()
    button(app, '마음 이야기').click().run()
    assert app.text_area[0].value == SELF_EXAMPLE
    button(app, '지우기').click().run()
    assert app.text_area[0].value == ''
