"""Train quick baseline signal detectors and report validation metrics.

This is exploratory labeling, not clinical diagnosis. Validation is from counseling dialogs,
not self-authored diaries; diary performance has not been established.
"""
import argparse
import gzip
import hashlib
import json
import pathlib
import pickle
import random

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import precision_recall_fscore_support

from prepare_data import SIGNALS


def read_data(path, max_rows=0):
    rows = []
    with gzip.open(path, 'rt', encoding='utf-8') as f:
        for line in f:
            rows.append(json.loads(line))
    # Never slice the front: files are grouped by disorder and this would
    # silently exclude some disorder-specific label types.
    if max_rows and len(rows) > max_rows:
        rows = random.Random(42).sample(rows, max_rows)
    return rows


def validate_subject_split(train_rows, validation_rows):
    train_ids = {r['subject_id'] for r in train_rows}
    valid_ids = {r['subject_id'] for r in validation_rows}
    if '' in train_ids or '' in valid_ids or 'UNKNOWN' in train_ids or 'UNKNOWN' in valid_ids:
        raise ValueError('Missing subject IDs prevent reliable split validation.')
    if train_ids & valid_ids:
        raise ValueError('Train/Validation subject overlap detected; re-split before training.')


def train(train_rows, validation_rows, output):
    validate_subject_split(train_rows, validation_rows)
    print(f'Training rows: {len(train_rows):,}, Validation rows: {len(validation_rows):,}')
    vectorizer = TfidfVectorizer(analyzer='char', ngram_range=(2, 3),
                                 min_df=3, max_features=40000, sublinear_tf=True,
                                 dtype=np.float32)
    X = vectorizer.fit_transform([r['text'] for r in train_rows])
    V = vectorizer.transform([r['text'] for r in validation_rows])
    models = {}
    scores = []
    for key, name in SIGNALS.items():
        tr_i = [i for i, row in enumerate(train_rows) if row.get(key) is not None]
        va_i = [i for i, row in enumerate(validation_rows) if row.get(key) is not None]
        y = np.array([train_rows[i][key] for i in tr_i], dtype=np.int32)
        if int(y.sum()) < 60 or len(y) - int(y.sum()) < 60 or len(va_i) == 0:
            print('Skip', key, 'insufficient labeled examples')
            continue
        clf = SGDClassifier(loss='log_loss', penalty='l2', alpha=0.0001,
                            class_weight='balanced', max_iter=15, tol=1e-3,
                            random_state=42)
        clf.fit(X[tr_i], y)
        pred = (clf.predict_proba(V[va_i])[:, 1] >= 0.5).astype(int)
        truth = [validation_rows[i][key] for i in va_i]
        precision, recall, f1, _ = precision_recall_fscore_support(
            truth, pred, average='binary', zero_division=0)
        models[key] = clf
        scores.append(dict(signal=key, title=name, validated_rows=len(va_i),
                           positive=sum(truth), precision=round(float(precision), 4),
                           recall=round(float(recall), 4), f1=round(float(f1), 4)))
        print(f'{key:24s} p={precision:.3f} r={recall:.3f} f1={f1:.3f}  validation_n={len(va_i)}')
    output = pathlib.Path(output)
    output.mkdir(exist_ok=True, parents=True)
    with (output / 'model.pkl').open('wb') as f:
        pickle.dump({'vectorizer': vectorizer, 'models': models, 'label_names': SIGNALS,
                     'threshold': 0.5}, f)
    with (output / 'metrics.json').open('w', encoding='utf-8') as f:
        json.dump({'validation_scope': '상담 대화 내담자 발화 (자유 입력 글 아님)',
                   'labels': scores}, f, ensure_ascii=False, indent=2)
    import sklearn
    with (output / 'model_manifest.json').open('w', encoding='utf-8') as f:
        json.dump({'sha256': hashlib.sha256((output / 'model.pkl').read_bytes()).hexdigest(),
                   'sklearn_version': sklearn.__version__, 'source': 'local retraining',
                   'license_verified': False}, f, indent=2)
    print('Model and validation scores saved to', output)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--data', default='data')
    p.add_argument('--output', default='artifacts')
    p.add_argument('--max-train', type=int, default=50000, help='Default: representative random subset for fast MVP; 0 means use all training data')
    args = p.parse_args()
    rows = read_data(pathlib.Path(args.data) / 'train.jsonl.gz')
    valid = read_data(pathlib.Path(args.data) / 'validation.jsonl.gz')
    validate_subject_split(rows, valid)  # Check full splits before representative sampling.
    if args.max_train and len(rows) > args.max_train:
        rows = random.Random(42).sample(rows, args.max_train)
    train(rows, valid, args.output)
