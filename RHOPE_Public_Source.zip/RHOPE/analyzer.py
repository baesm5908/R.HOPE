"""Existing inference contract. Only the verified model is cached; input is not."""
import hashlib
import io
import json
import os
import pickle
import re
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODES = ('본인 직접 입력', '상담사 입력')


class ModelUnavailable(RuntimeError):
    pass


class InputError(ValueError):
    pass


class RestrictedModelUnpickler(pickle.Unpickler):
    """Permit only classes used by the supplied baseline, never arbitrary globals."""
    ALLOWED = {
        ('sklearn.feature_extraction.text', 'TfidfVectorizer'),
        ('sklearn.feature_extraction.text', 'TfidfTransformer'),
        ('sklearn.linear_model._stochastic_gradient', 'SGDClassifier'),
        ('sklearn._loss._loss', 'CyHalfBinomialLoss'),
        ('numpy', 'float32'), ('numpy', 'ndarray'), ('numpy', 'dtype'),
        ('numpy._core.multiarray', '_reconstruct'),
        ('numpy._core.multiarray', 'scalar'),
        ('numpy.core.multiarray', '_reconstruct'),
        ('numpy.core.multiarray', 'scalar'),
    }

    def find_class(self, module, name):
        if (module, name) == ('_loss', 'CyHalfBinomialLoss'):
            # Supplied model serialized the compiled loss under its short module name.
            from sklearn._loss._loss import CyHalfBinomialLoss
            return CyHalfBinomialLoss
        if (module, name) not in self.ALLOWED:
            raise pickle.UnpicklingError('허용되지 않은 모델 객체')
        return super().find_class(module, name)


def parse_user_input(raw: str, mode: str):
    if mode not in MODES:
        raise InputError('지원하지 않는 입력 방식입니다.')
    if mode == '상담사 입력':
        lines, chunk, who = [], [], None
        for line in raw.splitlines():
            hit = re.match(r'^\s*(상담사|내담자)\s*[:：]\s*(.*)', line)
            if hit:
                if who == '내담자' and chunk:
                    lines.append('\n'.join(chunk).strip())
                who, chunk = hit.group(1), [hit.group(2)]
            elif re.match(r'^\s*[^\s:：]{1,12}\s*[:：]', line):
                raise InputError('화자는 상담사: 또는 내담자:로 구분해 주세요.')
            elif line.strip() and who is None:
                raise InputError('각 발화 앞에 상담사: 또는 내담자:를 붙여 주세요.')
            elif who is not None:
                chunk.append(line)
        if who == '내담자' and chunk:
            lines.append('\n'.join(chunk).strip())
        return [s for s in lines if len(s) >= 8]
    parts = re.split(r'(?<=[.!?。])\s+|\n+', raw)
    parts = [s.strip() for s in parts if len(s.strip()) >= 8]
    return parts if parts else ([raw.strip()] if len(raw.strip()) >= 8 else [])


@lru_cache(maxsize=2)
def _load_verified(path, manifest_path, modified_ns, manifest_modified_ns):
    try:
        blob = Path(path).read_bytes()
        manifest = json.loads(Path(manifest_path).read_text(encoding='utf-8'))
        if hashlib.sha256(blob).hexdigest() != manifest['sha256']:
            raise ModelUnavailable('모델 무결성 검사에 실패했습니다. 신뢰된 원본을 확인해 주세요.')
        import sklearn
        if sklearn.__version__ != manifest['sklearn_version']:
            raise ModelUnavailable('모델과 scikit-learn 버전이 다릅니다. requirements.txt로 설치해 주세요.')
        bundle = RestrictedModelUnpickler(io.BytesIO(blob)).load()
        if not {'vectorizer', 'models', 'label_names'} <= bundle.keys():
            raise ModelUnavailable('모델 형식이 올바르지 않습니다.')
        return bundle
    except ModelUnavailable:
        raise
    except Exception:
        raise ModelUnavailable('모델 연결 필요: 신뢰된 모델과 검증 manifest를 설치해 주세요.') from None


def load_model(model_path=None):
    path = Path(model_path or os.getenv('RHOPE_MODEL_PATH', ROOT / 'artifacts/model.pkl'))
    manifest = Path(os.getenv('RHOPE_MODEL_MANIFEST', path.with_name('model_manifest.json')))
    try:
        return _load_verified(str(path.resolve()), str(manifest.resolve()),
                              path.stat().st_mtime_ns, manifest.stat().st_mtime_ns)
    except OSError:
        raise ModelUnavailable('모델 연결 필요: 서버에 model.pkl과 model_manifest.json이 없습니다.') from None


def analyze_text(raw: str, mode: str, model_path=None):
    """Preserve the original fields and optional model_path compatibility."""
    if not isinstance(raw, str) or len(raw) > 10000:
        raise InputError('입력은 최대 10,000자까지 가능합니다.')
    parts = parse_user_input(raw, mode)
    if not parts:
        return {'mode': mode, 'analyzed_units': 0, 'signals': [],
                'limitations': '분석 가능한 내담자 발화 또는 사용자 글을 찾지 못했습니다.'}
    bundle = load_model(model_path)
    X = bundle['vectorizer'].transform(parts)
    signals = []
    threshold = bundle.get('threshold', 0.5)
    for key, clf in bundle['models'].items():
        probs = clf.predict_proba(X)[:, 1]
        selections = [i for i, p in enumerate(probs) if p >= threshold]
        if selections:
            selections.sort(key=lambda i: -probs[i])
            signals.append({'key': key, 'label': bundle['label_names'][key],
                            'count': len(selections), 'evidence': [parts[i] for i in selections[:3]]})
    signals.sort(key=lambda s: -s['count'])
    limitation = ('자유롭게 작성한 글에 대해서는 현재 모델의 정량적 성능이 검증되지 않았습니다.'
                  if mode == '본인 직접 입력' else
                  '상담 대화 기반의 탐색적 자동 라벨링이며 의학적 진단이나 개인의 위험도 판정이 아닙니다.')
    return {'mode': mode, 'analyzed_units': len(parts), 'signals': signals, 'limitations': limitation}
