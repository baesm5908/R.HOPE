"""R.HOPE Streamlit MVP, extended without replacing its model or framework."""
from pathlib import Path
import json
import os
import altair as alt
import pandas as pd
import streamlit as st
from analyzer import InputError, ModelUnavailable, load_model
from service import (QUESTIONS, SOURCES, SELF_EXAMPLE, TRANSCRIPT_EXAMPLE,
                     MAX_CHARS, guided_text, run_analysis, create_report)

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title='R.HOPE · 마음을 잇는 첫 대화', page_icon='🌿', layout='wide')
st.markdown((ROOT / 'assets/style.html').read_text(encoding='utf-8'), unsafe_allow_html=True)

PAGES = {'home': '홈', 'story': '마음 이야기', 'result': '분석 결과', 'counselor': '상담사 검토', 'research': '연구 결과'}
DEFAULTS = {'page': 'home', 'source': 'guided', 'drafts': {'direct': '', 'transcript': ''},
            'answers': ['', '', '', ''], 'step': 0, 'result': None,
            'shared_id': None, 'review': None, 'discussion': '', 'transcript_consent': False,
            'analysis_error': None, 'share_error': False}
for key, value in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = value
s = st.session_state
query_page = st.query_params.get('page', s.page)
if query_page in PAGES:
    s.page = query_page


def go(page, source=None):
    s.page = page
    st.query_params['page'] = page
    if source:
        s.source = source


def erase_all():
    for key in list(s):
        del s[key]
    st.query_params.clear()


def remember(source):
    s.drafts[source] = s['text_' + source]


def set_example(source):
    text = SELF_EXAMPLE if source == 'direct' else TRANSCRIPT_EXAMPLE
    s.drafts[source] = text
    s['text_' + source] = text


def clear_text(source):
    s.drafts[source] = ''
    s['text_' + source] = ''


def remember_answer(index):
    s.answers[index] = s[f'answer_{index}']


def reset_guide():
    s.answers = ['', '', '', '']
    s.step = 0
    for i in range(4):
        s[f'answer_{i}'] = ''


def guide_move(step, skip=False):
    if skip:
        s.answers[s.step] = ''
        s[f'answer_{s.step}'] = ''
    s.step = step


def analyze(text, source):
    try:
        with st.spinner('작성하신 표현을 실제 모델로 살펴보고 있어요…'):
            result = run_analysis(text, source, s.transcript_consent)
        s.result = result
        s.analysis_error = None
        s.shared_id, s.review, s.discussion = None, None, ''
        for key in ('share_check', 'discussion_input', 'review_note', 'review_status'):
            s.pop(key, None)
        go('result')
    except (InputError, ModelUnavailable) as e:
        s.analysis_error = str(e)
    except Exception:
        # Never print input, traceback, or serialized session to the UI/log.
        s.analysis_error = '분석 요청을 처리하지 못했습니다. 입력 형식과 모델 연결을 확인하고 다시 시도해 주세요.'


def share_result():
    s.share_error = not s.get('share_check', False)
    if not s.share_error and s.result:
        s.shared_id = s.result['id']
        go('counselor')


def share_change():
    s.share_error = False
    if not s.get('share_check', False):
        s.shared_id, s.review = None, None
        for key in ('review_status', 'review_note'):
            s.pop(key, None)


def model_status():
    try:
        bundle = load_model()
        return len(bundle['models']), None
    except ModelUnavailable as e:
        return None, str(e)


def title(eyebrow, heading, description):
    st.markdown(f'<div class="eyebrow">{eyebrow}</div>', unsafe_allow_html=True)
    st.title(heading)
    st.write(description)


def static_card(number, heading, body):
    st.markdown(f'<div class="feature-card"><span class="card-number">{number}</span><h3>{heading}</h3><p>{body}</p></div>', unsafe_allow_html=True)


def download_chart(chart, filename):
    st.download_button('차트 내려받기 (Vega-Lite JSON)', chart.to_json(), filename, 'application/json', key=filename)


with st.container(key='header'):
    st.markdown('<div class="brand"><span class="brand-mark">∿</span> R.HOPE <span class="brand-sub">Rope of Hope</span><span class="research-tag">연구·시연용</span></div>', unsafe_allow_html=True)
    nav = st.columns(5)
    for col, (key, label) in zip(nav, PAGES.items()):
        col.button(label, key='nav_' + key, type='primary' if s.page == key else 'secondary',
                   use_container_width=True, on_click=go, args=(key,))

if s.page == 'home':
    st.markdown('''<section class="hero">
+      <div class="hero-copy"><div class="eyebrow">A LITTLE CONVERSATION, A NEW BEGINNING</div>
+      <h1>말하기 어려웠던 마음,<br><span>R.HOPE</span>와 먼저<br>이야기해보세요.</h1>
+      <p>지금의 고민을 편하게 적고,<br>대화 속 심리적 신호와 그 근거를 함께 살펴보세요.</p>
+      <div class="hero-pill">마음을 이해하는 시작 · 사람에게 이어지는 대화</div></div>
+      <div class="hero-art" aria-hidden="true"><svg viewBox="0 0 440 400" xmlns="http://www.w3.org/2000/svg">
+      <circle cx="220" cy="190" r="165" fill="#e3f2ed"/><circle cx="220" cy="190" r="125" fill="#eef8f4"/>
+      <path d="M90 315 C110 225 100 80 198 90 C304 102 120 295 240 294 C353 294 272 82 358 74" stroke="#136f75" stroke-width="13" fill="none" stroke-linecap="round"/>
+      <path d="M90 315 C110 225 100 80 198 90 C304 102 120 295 240 294 C353 294 272 82 358 74" stroke="#74bda7" stroke-width="3" stroke-dasharray="3 7" fill="none"/>
+      <circle cx="90" cy="315" r="18" fill="#48b9a6"/><circle cx="358" cy="74" r="18" fill="#48b9a6"/>
+      <path d="M335 324 C320 295 344 284 348 300 C353 282 380 293 362 310Z" fill="#d8b577"/>
+      <circle cx="78" cy="105" r="5" fill="#d8b577"/><circle cx="382" cy="216" r="6" fill="#8ebdad"/></svg>
+      <div class="art-note">마음과 마음을 잇는 작은 시작</div></div></section>'''.replace('\n+', '\n'), unsafe_allow_html=True)
    c1, c2, _ = st.columns([1.4, 1.4, 2.2])
    c1.button('마음 이야기 시작하기 →', type='primary', use_container_width=True, on_click=go, args=('story', 'guided'))
    c2.button('연구 결과 살펴보기', use_container_width=True, on_click=go, args=('research',))
    st.markdown('<div class="section-heading"><span class="eyebrow">YOUR FIRST STEP</span><h2>어떤 방식이 편하신가요?</h2><p>이야기의 시작은 달라도, 근거를 살펴보는 과정은 같아요.</p></div>', unsafe_allow_html=True)
    for col, source, number, heading, body, action in zip(st.columns(3),
            ('guided', 'direct', 'transcript'), ('01', '02', '03'),
            ('AI와 이야기하기', '직접 글 작성', '상담 기록 분석'),
            ('네 가지 질문을 따라 지금의 마음을 천천히 정리해요. 고정 질문 기반 사전대화입니다.',
             '일기, 고민, 감정과 경험을 나의 말로 자유롭게 적어보세요.',
             '동의받고 비식별화한 대화에서 내담자의 표현만 살펴봅니다.'),
            ('가이드 대화 시작', '직접 작성 시작', '상담 기록 입력')):
        with col, st.container(border=True):
            static_card(number, heading, body)
            st.button(action + ' →', key='start_' + source, use_container_width=True, on_click=go, args=('story', source))
    st.markdown('<div class="section-heading"><span class="eyebrow">FROM WORDS TO UNDERSTANDING</span><h2>결과보다, 이해를 위한 근거</h2></div>', unsafe_allow_html=True)
    st.markdown('''<div class="value-grid"><div><b>복합 요인 탐색</b><p>하나의 이름으로 단정하지 않아요.</p></div><div><b>요인 동시출현</b><p>함께 탐지된 표현을 살펴봐요.</p></div><div><b>실제 근거 문장</b><p>작성한 원문에서 근거를 찾아요.</p></div><div><b>전문가 상담 준비</b><p>이야기를 정리해 상담을 준비해요.</p></div></div>''', unsafe_allow_html=True)
    st.info('AI는 상담사를 대체하지 않습니다. 이야기 정리와 표현 탐색을 돕는 공모전 연구·시연용 프로토타입이며, 최종 전문적 판단은 상담사가 합니다.')

elif s.page == 'story':
    title('YOUR STORY', '마음 이야기', '잘 정리된 말이 아니어도 괜찮아요. 편한 방식으로, 나의 속도로 시작해보세요.')
    choices = st.columns(3)
    for col, source, label in zip(choices, SOURCES, ('직접 글 작성', 'AI와 이야기하기', '상담 기록 분석')):
        col.button(label, key='choose_' + source, type='primary' if s.source == source else 'secondary', use_container_width=True, on_click=go, args=('story', source))
    st.caption('공개 시연에는 가상 사례만 사용하세요. 입력은 분석 서버와 현재 세션 메모리에서 처리되며 DB·외부 AI API에 저장·전송하지 않습니다. 호스팅 인프라 정책은 별도 확인이 필요합니다.')
    if s.analysis_error:
        st.error(s.analysis_error)
    if s.source == 'guided':
        st.info('고정 질문 기반 가이드입니다. 자유 생성 LLM 상담이 아닙니다. 질문은 분석하지 않고 직접 작성한 답변만 분석합니다.')
        st.progress(s.step / 4, text=f'{min(s.step + 1, 4)} / 4 단계' if s.step < 4 else '답변 정리 완료')
        for i in range(min(s.step, 4)):
            with st.chat_message('assistant'):
                st.write(QUESTIONS[i])
            with st.chat_message('user'):
                st.text(s.answers[i] or '이 질문은 건너뛰었어요.')
                st.button('답변 편집', key=f'edit_answer_{i}', on_click=guide_move, args=(i,))
        if s.step < 4:
            i = s.step
            with st.chat_message('assistant'):
                st.write(QUESTIONS[i])
            key = f'answer_{i}'
            if key not in s:
                s[key] = s.answers[i]
            st.text_area('나의 답변', key=key, height=140, max_chars=2500, on_change=remember_answer, args=(i,), placeholder='편하게 적어주세요. 답하기 어려운 질문은 건너뛸 수 있어요.')
            st.caption(f'{len(s[key]):,} / 2,500자 · 전체 답변 최대 10,000자')
            previous, skip, following = st.columns(3)
            previous.button('← 이전 질문', disabled=i == 0, use_container_width=True, on_click=guide_move, args=(max(0, i-1),))
            skip.button('건너뛰기', use_container_width=True, on_click=guide_move, args=(i+1, True))
            following.button('답변 저장 · 다음 →' if i < 3 else '답변 정리하기 →', type='primary', use_container_width=True, on_click=guide_move, args=(i+1,))
        else:
            text = guided_text(s.answers)
            st.caption(f'작성한 답변 총 {len(text):,}자 · 최소 20자')
            st.button('답변에서 심리 신호 살펴보기', type='primary', use_container_width=True,
                      on_click=analyze, args=(text, 'guided'))
        st.button('처음부터 다시하기', on_click=reset_guide)
    else:
        source = s.source
        if source == 'transcript':
            st.warning('실제 상담 자료는 당사자 동의·비식별화·접근권한·법적 검토 없이 공개 서버에 입력하지 마세요. 이름·연락처·주민등록번호를 제거하세요.')
            if 'consent_widget' not in s:
                s.consent_widget = s.transcript_consent
            st.checkbox('당사자 동의 및 비식별화를 확인했습니다. 공개 시연에는 가상 사례를 사용합니다.', key='consent_widget', on_change=lambda: s.update(transcript_consent=s.consent_widget))
        else:
            st.caption('자유롭게 작성한 글에 대해서는 현재 모델의 정량적 성능이 검증되지 않았습니다.')
        key = 'text_' + source
        if key not in s:
            s[key] = s.drafts[source]
        st.text_area('최근의 생각, 감정, 경험' if source == 'direct' else '상담 대화 · 상담사: / 내담자: 형식', key=key, height=260,
                     max_chars=MAX_CHARS, on_change=remember, args=(source,), placeholder=SELF_EXAMPLE if source == 'direct' else TRANSCRIPT_EXAMPLE)
        st.caption(f'{len(s[key]):,} / {MAX_CHARS:,}자 · 최소 20자 · 8자 이상 문장/발화 분석')
        c1, c2, c3 = st.columns([1.4, 1, 1.5])
        c1.button('가상 예시로 체험하기', key='example_' + source, on_click=set_example, args=(source,), use_container_width=True)
        c2.button('지우기', key='clear_' + source, on_click=clear_text, args=(source,), use_container_width=True)
        c3.button('심리 신호 살펴보기 →', type='primary', use_container_width=True,
                  on_click=analyze, args=(s[key], source))
        if source == 'transcript':
            st.caption('내담자 발화만 분석합니다. 여러 줄 발화도 지원하며, 화자 표기가 없거나 내담자 발화가 없으면 분석을 중단합니다.')
    _, error = model_status()
    if error:
        st.error(error)

elif s.page == 'result':
    title('WORDS, WITH CONTEXT', '마음의 신호 살펴보기', '내가 쓴 표현과 근거를 함께 읽어보세요. 결과는 진단이나 개인의 위험도 점수가 아닙니다.')
    result = s.result
    if not result:
        st.info('아직 분석한 이야기가 없어요. 먼저 마음 이야기를 작성해 주세요.')
        st.button('마음 이야기 시작하기', type='primary', on_click=go, args=('story', 'direct'))
    else:
        st.caption(f"{SOURCES[result['source']]} · {result['created_at']} (한국 시간)")
        a, b, c = st.columns(3)
        a.metric('분석 문장/발화', f"{result['analyzed_units']}개")
        b.metric('탐지된 요인 종류', f"{len(result['signals'])}개")
        c.metric('분석 방식', '실제 초기 모델')
        if not result['signals']:
            st.info('현재 모델이 표시할 관련 표현을 찾지 못했습니다. 문제가 없다는 뜻은 아닙니다.')
        else:
            st.subheader('표현의 분포')
            st.caption('단위: 탐지된 문장/발화 수. 요인별 수는 중복될 수 있으며 심각도나 확률이 아닙니다.')
            data = pd.DataFrame([{'심리요인': r['label'], '탐지된 문장/발화 수': r['count']} for r in result['signals']])
            chart = alt.Chart(data).mark_bar(color='#136F75', cornerRadiusEnd=5).encode(
                x=alt.X('탐지된 문장/발화 수:Q', axis=alt.Axis(tickMinStep=1)),
                y=alt.Y('심리요인:N', sort='-x', title=None), tooltip=list(data.columns)).properties(height=max(180, len(data)*35))
            st.altair_chart(chart, use_container_width=True)
            st.subheader('내 문장에서 찾은 근거')
            st.caption('관련 문장/발화에서 모델 점수가 높은 순서로 최대 3개를 보여줍니다. 원문 그대로이며 점수는 출력하지 않습니다.')
            for signal in result['signals']:
                with st.expander(f"{signal['label']} · 관련 문장/발화 {signal['count']}개", expanded=True):
                    for evidence in signal['evidence']:
                        st.text(evidence)
            if len(result['signals']) > 1:
                st.subheader('이번 입력에서 함께 탐지된 요인')
                st.write(' · '.join(result['patterns']['labels']))
                st.caption('입력 전체에서 함께 탐지됐다는 뜻입니다. 같은 발화의 동시출현, 학습 데이터 통계 또는 인과관계는 아닙니다.')
        st.warning(result['limitations'])
        st.caption('사회적 지지·대처 방식 탐지는 부족 또는 부적절함을 의미하지 않습니다. 오탐과 누락이 있으며 의료적 검증이 없습니다.')
        st.subheader('상담 준비 보고서')
        with st.expander('원문 기반 정리 확인', expanded=False):
            st.caption('앞 5개 분석 단위를 발췌했습니다. 생성형 AI 자동 요약이 아닙니다.')
            for text in result['excerpts']:
                st.text(text)
        if 'discussion_input' not in s:
            s.discussion_input = s.discussion
        st.text_area('추가로 대화하고 싶은 내용 (선택)', key='discussion_input', max_chars=2000,
                     on_change=lambda: s.update(discussion=s.discussion_input))
        report = create_report(result, s.discussion)
        with st.expander('보고서 생성 · 내용 미리보기'):
            st.text(report)
        a, b, c = st.columns(3)
        a.download_button('보고서 다운로드 (.md)', report, f"RHOPE_{result['id']}.md", 'text/markdown; charset=utf-8', use_container_width=True)
        b.download_button('보고서 다운로드 (.txt)', report, f"RHOPE_{result['id']}.txt", 'text/plain; charset=utf-8', use_container_width=True)
        c.download_button('결과 내보내기 (.json)', json.dumps(result, ensure_ascii=False, indent=2), f"RHOPE_{result['id']}.json", 'application/json', use_container_width=True)
        st.caption('다운로드는 사용자가 선택할 때만 실행됩니다. 다운로드한 파일의 보관·공유에 유의해 주세요. 기관 또는 상담사에게 자동 전송하지 않습니다.')
        if 'share_check' not in s:
            s.share_check = s.shared_id == result['id']
        st.checkbox('현재 결과를 같은 브라우저 세션의 시연용 상담사 미리보기에 표시하는 데 동의합니다.', key='share_check', on_change=share_change)
        st.button('동의 후 상담사 미리보기 열기', type='primary', on_click=share_result)
        if s.share_error:
            st.warning('미리보기를 열려면 표시 동의가 필요합니다.')
        a, b = st.columns(2)
        a.button('← 입력 수정하기', on_click=go, args=('story', result['source']), use_container_width=True)
        b.button('모든 기록 지우고 새 이야기', on_click=erase_all, use_container_width=True)

elif s.page == 'counselor':
    title('HUMAN REVIEW', '상담사 검토 미리보기', '같은 브라우저의 현재 세션에서만 사용하는 시연용 검토 흐름입니다. 최종 전문적 판단은 상담사가 합니다.')
    st.info('운영용 전문가 로그인, 원격 전송·기관 예약·상담사 매칭은 제공하지 않습니다. 다른 사용자의 보고서 목록도 제공하지 않습니다.')
    result = s.result
    if not result or s.shared_id != result['id']:
        st.warning('표시 동의를 받은 현재 세션의 보고서가 없습니다. 분석 결과에서 동의 후 미리보기를 열어 주세요.')
        st.button('분석 결과로 이동', on_click=go, args=('result',))
    else:
        st.caption(f"현재 세션 보고서 · {result['id']}")
        st.subheader('원문과 탐지 근거')
        st.text(create_report(result, s.discussion))
        old = s.review or {'status': '추가 상담 논의', 'note': ''}
        statuses = ['추가 상담 논의', '전문가 상담 권고 검토', '추적 확인', '기타']
        with st.form('review_form'):
            status = st.selectbox('수동 검토 선택', statuses, index=statuses.index(old['status']), key='review_status')
            note = st.text_area('검토 메모', value=old['note'], max_chars=2000, key='review_note')
            if st.form_submit_button('검토 저장 / 수정', type='primary'):
                s.review = {'status': status, 'note': note}
                st.success('현재 세션 메모리에 검토 내용을 저장했습니다.')
        if s.review:
            st.caption('현재 저장된 검토 선택: ' + s.review['status'])
            st.text(s.review['note'])
            st.download_button('검토 포함 보고서 다운로드', create_report(result, s.discussion, s.review), f"RHOPE_review_{result['id']}.md", 'text/markdown; charset=utf-8')
        def revoke():
            s.shared_id, s.review = None, None
            for key in ('review_status', 'review_note', 'share_check'):
                s.pop(key, None)
        st.button('미리보기 동의 철회 · 검토 초기화', on_click=revoke)

elif s.page == 'research':
    title('RESEARCH, TRANSPARENTLY', '데이터와 모델 연구', '잘하는 것과 아직 부족한 것을 함께 공개합니다. 연구 지표는 개인의 신뢰도나 진단 확률이 아닙니다.')
    st.info('연구 질문: 같은 우울·불안·중독 범주 안에서도 서로 다른 심리적 위험·보호 요인 조합이 관찰되는가? 현재는 표현 라벨 기반의 탐색 단계입니다.')
    def read_json(variable, filename):
        path = Path(os.getenv(variable, ROOT / 'artifacts' / filename))
        try:
            return json.loads(path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return None
    metrics = read_json('RHOPE_METRICS_PATH', 'metrics.json')
    research = read_json('RHOPE_RESEARCH_PATH', 'research_summary.json')
    revalidation = read_json('RHOPE_VALIDATION_CHECK_PATH', 'validation_check.json')
    with st.expander('데이터 출처·해석 범위', expanded=True):
        st.write('AI Hub 심리상담 자료로 제공된 ZIP을 사용했습니다. 원본 데이터셋의 정확한 명칭·라벨링 가이드·라이선스·공개 배포 권한은 아직 확인되지 않았습니다.')
        st.write('상담사 발화는 제외하고 공백 정규화 후 8자 이상인 내담자 발화를 집계합니다. 분석 단위는 발화이며 패턴은 세션 단위입니다. 다회기 내담자의 반복 관측 편향이 있습니다.')
        st.caption('기획서의 전체 규모와 확보 자료 규모는 동일하지 않습니다. 확인하지 못한 Training 수치나 누락 자료 수를 검증 완료 수치로 표시하지 않습니다.')
    data_tab, metric_tab, pattern_tab = st.tabs(['데이터 현황', '모델 검증', '동시출현 연구'])
    with data_tab:
        if not research:
            st.warning('아직 분석되지 않음 · 로컬 자료로 prepare_research.py를 실행하면 익명 집계를 표시합니다.')
        else:
            st.caption(f"집계 실행 시각 (UTC): {research['generated_at']}")
            st.warning(research['label_definition'])
            for split in ('Training', 'Validation'):
                if split not in research['splits']:
                    st.info(split + ': 아직 분석되지 않음 · 원본 파일에 접근하지 못해 집계·분할 검증을 실행하지 않았습니다.')
                    continue
                entry = research['splits'][split]
                stats = entry['stats']
                st.subheader(split + ' 실제 파일 집계')
                a, b, c, d = st.columns(4)
                a.metric('라벨 JSON 세션', f"{stats['total_sessions']:,}")
                b.metric('파싱 성공', f"{stats['parsed_sessions']:,}")
                c.metric('파싱 오류', f"{stats['invalid_sessions']:,}")
                d.metric('분석 내담자 발화', f"{stats['client_paragraphs']:,}")
                groups = pd.DataFrame([{'질환군 (원자료)': k, '확보 세션 수': v, '파싱 성공 수': entry['group_parsed'].get(k, 0)} for k, v in entry['group_sessions'].items()])
                group_chart = alt.Chart(groups).mark_bar(color='#48B9A6', cornerRadiusEnd=4).encode(x=alt.X('질환군 (원자료):N', title=None), y='확보 세션 수:Q', tooltip=list(groups.columns)).properties(height=240)
                st.altair_chart(group_chart, use_container_width=True)
                st.dataframe(groups, hide_index=True, use_container_width=True)
                download_chart(group_chart, f'{split}_groups.vega.json')
                st.subheader(split + ' 요인별 라벨 분포')
                label_df = pd.DataFrame(entry['labels']).drop(columns='key').rename(columns={'label': '요인', 'positive': '양성 발화', 'negative': '음성 발화', 'unlabeled': '미라벨 발화'})
                st.dataframe(label_df, hide_index=True, use_container_width=True)
                st.download_button('라벨 집계 CSV 다운로드', label_df.to_csv(index=False).encode('utf-8-sig'), f'{split}_labels.csv', 'text/csv', key=split + '_csv')
                with st.expander('질환군별 라벨 분포·적격 표본'):
                    for group, labels in entry['labels_by_group'].items():
                        st.write(group)
                        frame = pd.DataFrame(labels).drop(columns='key').rename(columns={'label': '요인', 'positive': '양성', 'negative': '음성', 'unlabeled': '미라벨'})
                        frame['적격 발화 수'] = frame['양성'] + frame['음성']
                        st.dataframe(frame, hide_index=True, use_container_width=True)
                with st.expander('파싱 오류 기록 (본문 없는 파일 해시 ID)'):
                    st.dataframe(pd.DataFrame(entry['errors']), hide_index=True, use_container_width=True)
            overlap = research['overlap_check']
            if overlap['status'] != 'checked':
                st.warning('Train/Validation 내담자 중복 검증: 미완료. 두 자료와 유효한 내담자 ID가 모두 필요합니다.')
            else:
                st.write(f"정규화된 내담자 ID 중복: {overlap['overlapping_subject_count']}개")
                if overlap['overlapping_subject_count']:
                    st.error('분할 간 내담자 중복이 있습니다. 성능 해석에 정보 누수 가능성을 반영하고 재분할 후 평가해야 합니다.')
    with metric_tab:
        if not metrics or not metrics.get('labels'):
            st.warning('검증 통계 없음 · metrics.json을 연결해 주세요.')
        else:
            st.caption('동봉 metrics.json 원본 수치입니다. Training 모델을 재학습하지 않았습니다.')
            if revalidation and revalidation.get('all_match'):
                st.success('제공된 Validation 원본으로 10개 모델을 재평가했고 모든 지표가 동봉 metrics.json과 일치했습니다.')
                st.caption('재평가 시각 (UTC): ' + revalidation['validated_at'] + ' · Train/Validation 내담자 중복 여부는 별도 미검증입니다.')
            else:
                st.caption('이 실행 환경에서 Validation 재평가 결과는 연결되지 않았습니다.')
            st.write('검증 범위: ' + metrics['validation_scope'])
            scores = pd.DataFrame(metrics['labels']).rename(columns={'title': '요인', 'validated_rows': '평가 발화 수', 'positive': '양성 발화 수', 'precision': 'Precision', 'recall': 'Recall', 'f1': 'F1'})
            chart = alt.Chart(scores).mark_bar(color='#136F75', cornerRadiusEnd=4).encode(x=alt.X('F1:Q', scale=alt.Scale(domain=[0, 1])), y=alt.Y('요인:N', sort='-x', title=None), tooltip=['요인', 'F1', 'Precision', 'Recall', '평가 발화 수', '양성 발화 수']).properties(height=370)
            st.altair_chart(chart, use_container_width=True)
            st.dataframe(scores.drop(columns='signal'), hide_index=True, use_container_width=True)
            download_chart(chart, 'model_f1.vega.json')
            st.download_button('검증 지표 JSON 다운로드', json.dumps(metrics, ensure_ascii=False, indent=2), 'metrics.json', 'application/json')
        st.warning('낮은 성능을 포함한 초기 기준 모델입니다. 요인별로 적격 평가 발화 수가 다릅니다. 개인 자유 글 성능·의료적 타당성은 검증되지 않았고 오탐·누락이 가능합니다.')
        count, error = model_status()
        if error:
            st.error(error)
        else:
            st.caption(f'연결된 실제 모델: {count}개 요인 · 문자 2–3 gram TF-IDF + SGDClassifier(log_loss), 고정 시드 42, 임계값 0.5. 모델 설정 기준이며 임계값은 UI의 위험도 확률이 아닙니다.')
    with pattern_tab:
        patterns = research.get('patterns') if research else None
        st.write('세션 단위 Training 라벨 동시출현')
        st.caption('각 요인 쌍의 라벨이 모두 한 번 이상 관측된 세션만 분모로 사용합니다. 양성은 해당 세션 내 하나 이상의 적격 발화에서 양수 라벨이 관찰된 경우입니다. 미라벨은 음성으로 계산하지 않습니다.')
        if patterns is None:
            st.info('아직 분석되지 않음 · Training ZIP이 필요합니다. Validation으로 패턴을 탐색하거나 가상의 Lift 수치를 만들지 않습니다.')
        else:
            names = {r['key']: r['label'] for r in research['splits']['Training']['labels']}
            matrix_rows = []
            for r in patterns['matrix']:
                for a, b in [(r['a'], r['b']), (r['b'], r['a'])]:
                    matrix_rows.append({'요인 A': names[a], '요인 B': names[b], '동시 양성 세션': r['both'], '적격 세션': r['eligible_sessions']})
            matrix = pd.DataFrame(matrix_rows)
            heatmap = alt.Chart(matrix).mark_rect().encode(x=alt.X('요인 A:N', axis=alt.Axis(labelLimit=140)), y='요인 B:N', color=alt.Color('동시 양성 세션:Q', scale=alt.Scale(scheme='tealblues')), tooltip=list(matrix.columns)).properties(height=400)
            st.altair_chart(heatmap, use_container_width=True)
            st.dataframe(matrix, hide_index=True, use_container_width=True)
            download_chart(heatmap, 'training_cooccurrence.vega.json')
            st.caption(f"최소 동시 양성 세션 조건: {patterns['minimum_both']}개. Support=동시 양성/쌍별 적격 세션; Confidence(A→B)=동시 양성/A 양성; Lift=Support/(A 양성 비율×B 양성 비율). 인과관계나 개인 위험도가 아닙니다.")
            if patterns['associations']:
                frame = pd.DataFrame(patterns['associations'])
                frame['a'], frame['b'] = frame['a'].map(names), frame['b'].map(names)
                st.dataframe(frame.rename(columns={'a': '요인 A', 'b': '요인 B', 'eligible_sessions': '적격 세션', 'both': '동시 양성 세션', 'a_positive': 'A 양성 세션', 'b_positive': 'B 양성 세션'}), hide_index=True, use_container_width=True)
                st.download_button('Training 조합 집계 CSV', frame.to_csv(index=False).encode('utf-8-sig'), 'training_patterns.csv', 'text/csv')
            else:
                st.info('최소 표본 조건을 만족하는 조합이 없습니다.')
            st.caption('반복 회기 편향·쌍별 분모 차이·희소성·여러 조합 탐색의 선택편향을 고려해야 합니다. Validation에는 별도 패턴 탐색을 수행하지 않습니다.')

st.divider()
with st.container(key='footer'):
    st.markdown('<div class="footer-brand">R.HOPE <span>마음과 마음을 잇는 희망의 연결</span></div>', unsafe_allow_html=True)
    st.caption('진단·치료·위험도 판정·실시간 위기 감지 서비스가 아닙니다. 즉각적인 위험이 있다면 119/112 및 주변의 신뢰할 수 있는 사람·전문가에게 연락하세요.')
    st.button('모든 기록 지우기', key='erase_all', on_click=erase_all)
    st.caption('기록은 현재 세션 메모리에만 유지됩니다. 지우기는 세션 상태를 초기화하며, 다운로드한 파일이나 호스팅 인프라 로그는 삭제하지 않습니다.')
