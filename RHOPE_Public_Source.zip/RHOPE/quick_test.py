"""Smoke test for pre-trained model. No real patient content used."""
from analyzer import analyze_text, parse_user_input

SELF = '요즘 잠이 잘 오지 않아서 아침에 피곤하고, 과제가 쌓여 고민이 많습니다. 친구와 이야기해 볼 생각이에요.'
DIALOG = ('상담사: 어떤 일이 있나요?\n내담자: ' + SELF +
          '\n상담사: 잠이 부족해서 힘들었군요.\n내담자: 며칠 동안 계속 피곤했습니다.')
assert parse_user_input(DIALOG, '상담사 입력')[0] == SELF
for mode, text in [('본인 직접 입력', SELF), ('상담사 입력', DIALOG)]:
    result = analyze_text(text, mode)
    assert result['analyzed_units'] > 0
    assert isinstance(result['signals'], list)
    assert all('상담사:' not in evidence for sig in result['signals'] for evidence in sig['evidence'])
    print(mode, 'OK, result labels =', [sig['label'] for sig in result['signals']])
print('All smoke tests passed (not a clinical validation).')
