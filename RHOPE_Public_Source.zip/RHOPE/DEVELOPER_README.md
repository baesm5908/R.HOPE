# R.HOPE · Rope of Hope

말하기 어려웠던 마음, R.HOPE와 먼저 이야기해보세요.

사용자가 제공한 **RHOPE_2day_MVP의 Streamlit·Python·scikit-learn 앱**을 확장한 한국어 연구·시연용 프로토타입입니다. 기존 웹 저장소에는 README만 있었으므로 첨부 MVP의 프레임워크, 10개 초기 모델, 분석 인터페이스 및 전처리·학습 코드를 이어서 사용했습니다. 진단, 치료 지시, 개인 위험도 확률, 실시간 위기 감지 서비스를 제공하지 않습니다.

## 빠른 실행

현재 클라우드 환경에서는 의존성과 신뢰된 모델을 설치했습니다.

```bash
cd /workspace/R.HOPE
bash scripts/run.sh
```

기본 포트는 **8501**입니다. `PORT=8502 bash scripts/run.sh`처럼 변경할 수 있습니다. 같은 포트에 이미 앱이 실행 중이면 중복 실행하지 마세요. 클라우드 작업은 이미 격리되어 있으므로 기존 체크아웃을 이용하고 별도 Git worktree를 만들 필요가 없습니다.

다른 로컬 환경에서는 Python **3.12**, 제공된 신뢰된 모델이 필요합니다.

```bash
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
# 아래 모델 확보 설명을 먼저 확인하세요.
python quick_test.py
python -m streamlit run app.py
```

클라우드 반복 설치는 `bash scripts/setup.sh`를 사용합니다. `RHOPE_VENV`로 가상환경 경로를 바꿀 수 있습니다. 핵심 버전은 numpy 2.2.6 / scikit-learn 1.8.0 / Streamlit 1.50.0 / pandas 2.3.3 / Altair 5.5.0으로 고정했습니다. 모델 학습 버전 1.8.0과 런타임 버전 일치가 필요합니다.

## 화면·기능

경로는 Streamlit 단일 서버의 쿼리 파라미터입니다. 별도 프론트 API 또는 FastAPI 서버가 필요하지 않습니다.

| 화면 | 경로 | 기능 |
|---|---|---|
| 홈 | `?page=home` | 3가지 입력 방식, 서비스 철학, 연구 이동 |
| 마음 이야기 | `?page=story` | 직접 작성, 4단계 고정 질문, 동의 기반 상담 기록 입력 |
| 개인 결과 | `?page=result` | 실제 모델 신호, 문장/발화 수 그래프, 원문 근거, 보고서·JSON 다운로드 |
| 상담사 검토 | `?page=counselor` | 같은 세션의 명시적 표시 동의, 메모·수동 선택 저장·수정·철회 |
| 연구 결과 | `?page=research` | 실제 데이터 집계·라벨 분포, 원본 지표, 재평가 결과, Training 동시출현 준비 |

분석은 버튼 클릭 시에만 실행됩니다. 사용자 답변 또는 내담자 발화만 모델에 전달합니다. `analyzer.analyze_text(raw, mode, model_path=None)`의 기존 mode/analyzed_units/signals/limitations 구조를 유지했습니다. 한국어 mode는 `본인 직접 입력`, `상담사 입력`입니다. count는 **탐지된 문장/발화 수**이며 확률이 아닙니다.

- 자유 글·가이드 답변: 최소 20자, 전체 최대 10,000자. 8자 이상 문장/행 단위 분석.
- 가이드: 답변당 2,500자, 이전·건너뛰기·편집·재시작. 생성형 LLM이 아닌 고정 질문입니다.
- 상담 기록: `상담사:` / `내담자:` 또는 전각 콜론 표기, 여러 줄 내담자 발화 지원. 화자 불명·내담자 0개·동의 없음은 오류로 안내합니다.
- 근거: 모델이 선택한 입력 원문 최대 3개. 모델/LLM이 새 문장을 생성하지 않습니다.
- 함께 탐지된 요인: **이번 입력 전체**의 탐지 결과이며 동일 발화의 동시출현·학습 자료 패턴·인과관계와 구분합니다.
- 보고서: 원문 앞 5개 분석 단위 발췌, 신호·근거·추가 논의·한계. `.md`, `.txt`, `.json`을 사용자가 직접 다운로드합니다. PDF는 미구현입니다.
- 상담사 미리보기: 같은 세션 메모리만 사용합니다. 운영용 로그인·병원 전송·예약·매칭은 없습니다.

## 모델 확보·환경 변수

`artifacts/model.pkl`은 **현재 작업 공간에만** 있으며 Git 및 Docker 빌드 컨텍스트에서 제외했습니다. 새 Git 클론에는 포함되지 않습니다. 배포 권한을 확인한 후 사용자가 제공한 MVP ZIP에서 `rhope_mvp/artifacts/model.pkl`을 개인 서버의 허가된 위치에 설치하세요. 재학습 없이 첨부 모델을 사용할 수 있습니다.

동봉 `model_manifest.json`은 첨부 원본의 SHA-256와 sklearn 버전을 담습니다. 모델 무결성 검증과 허용된 sklearn/numpy 클래스만 로드하는 제한된 역직렬화를 적용했습니다. 임의의 다운로드 피클을 로드하거나 체크섬 검사를 우회하지 마세요. 재학습 스크립트는 새 모델과 새 manifest를 같이 만듭니다. **새 모델의 manifest를 리뷰·검증한 뒤 배포**해야 합니다. 체크섬은 출처의 안전성이나 라이선스를 보증하지 않습니다.

| 변수 | 기본값 | 용도 |
|---|---|---|
| `RHOPE_MODEL_PATH` | 저장소 `artifacts/model.pkl` | 허가된 로컬 모델 |
| `RHOPE_MODEL_MANIFEST` | 모델과 같은 폴더 `model_manifest.json` | 모델 checksum·버전 |
| `RHOPE_METRICS_PATH` | `artifacts/metrics.json` | 원본 익명 검증 지표 |
| `RHOPE_RESEARCH_PATH` | `artifacts/research_summary.json` | 로컬 익명 집계 |
| `RHOPE_VALIDATION_CHECK_PATH` | `artifacts/validation_check.json` | 이번 재평가 결과 |
| `RHOPE_VENV` | `/workspace/rhope-venv` | 클라우드 스크립트용 |
| `PORT` | `8501` | 실행 스크립트용 |

`.env.example`은 변수명 예시이며 앱은 `.env`를 자동으로 읽지 않습니다. 셸에서 `export`하거나 호스팅 설정에 등록하세요. API 키는 필요하지 않습니다. 모델이 없거나 무결성 검사에 실패하면 **모델 연결 필요**를 표시하며 가짜 결과로 대체하지 않습니다.

## 실제 데이터·연구 현황

- Validation ZIP을 직접 읽어 라벨 JSON **176개**, 정상 **174개**, 오류 **2개**를 확인했습니다.
- `paragraph_speaker == '내담자'`이며 공백 정규화 후 8자 이상인 발화 **16,700개**를 확인했습니다.
- 오류 로그는 원문·원본 파일명 대신 파일 경로의 SHA-256 앞 16자리 ID만 출력합니다.
- 실제 Validation으로 10개 모델을 재평가한 평가행 수·양성 수·Precision·Recall·F1이 **동봉 metrics.json과 모두 일치**했습니다. 원본 `metrics.json`은 수정하지 않았습니다.
- 제공된 Training.zip은 도구의 **32MiB 다운로드 제한**으로 접근하지 못했습니다. 따라서 이전 문서의 Training/전체 규모를 이번 검증 결과로 표시하지 않습니다.
- Training 세션 동시출현·Support/Confidence/Lift 및 Train/Validation 내담자 중복 검사는 **미완료**입니다. 화면에는 '아직 분석되지 않음'으로 표시합니다. 전체 파이프라인과 차트·표·다운로드는 구현했고 합성 데이터로 검증했습니다.
- 양수 라벨을 임시 양성, 0을 음성, 결측·비수치·음수를 미라벨로 취급합니다. 공식 라벨 가이드·별칭의 의미는 미확인이라 오타 별칭을 무조건 합치지 않습니다. 사회적 지지와 대처 방식은 부족·부적절함으로 해석하지 않습니다.
- 상담 전사 모델의 **개인 자유 글 정량 성능은 미검증**이며 의료적 타당성이 없습니다.

Training은 라벨링데이터만 담은 32MiB 이하의 허가된 자료 또는 접근 가능한 로컬 경로로 제공하면 후속 집계를 실행할 수 있습니다. 민감 자료를 공개 저장소에 넣지 마세요.

```bash
# 원문 없이 익명 집계만 생성 (Training은 사용 가능할 때 지정)
python prepare_research.py --training /private/Training.zip --validation /private/Validation.zip
# Validation만 준비됐을 때
python prepare_research.py --validation /private/Validation.zip
# 원본 모델을 재평가. metrics.json은 덮어쓰지 않음.
python validate_model.py --validation /private/Validation.zip
# 재학습은 별도 연구 작업. 먼저 ID 중복 및 라벨 정의 확인.
python prepare_data.py --training /private/Training.zip --validation /private/Validation.zip
python train_model.py --data data --output private_data/retrained --max-train 50000
```

동시출현 탐색은 **Training만** 이용합니다. 세션마다 각 요인의 적격·양성 상태를 계산하고 각 쌍의 라벨이 모두 관측된 세션을 쌍별 분모로 사용합니다. 최소 동시 양성 세션 수는 기본 5개입니다. Support=동시 양성/쌍별 적격 세션, Confidence(A→B)=동시 양성/A 양성, Lift=Support/(A 비율×B 비율). 세션 반복에 따른 내담자 가중 편향·희소성·결측·다중 탐색 선택편향에 유의하세요.

## 개인정보·권한

입력·보고서·검토 메모를 DB, 파일, 로컬스토리지 또는 외부 LLM/분석 도구에 저장하지 않습니다. 모델 리소스만 캐싱하고 입력 결과는 캐싱하지 않습니다. 민감한 본문을 요청 로그·예외 로그에 출력하지 않습니다. 사용자 텍스트는 `st.text`로 안전하게 출력하며 사용자 문자열을 HTML 렌더링에 넣지 않습니다. 원천 데이터/모델/전처리 산출물/사용자 보고서/환경 변수·토큰은 Git 추적에서 제외합니다.

서버는 요청과 세션 메모리를 처리하므로 '브라우저 밖으로 전송되지 않는다'고 주장하지 않습니다. 서버 종료·세션 만료 시 기록은 사라질 수 있으며, `모든 기록 지우기`로 현재 세션을 초기화합니다. 이미 다운로드한 파일·호스팅 접근 로그의 삭제는 별도입니다. 공개 시연에는 **가상 예시만** 사용하세요. 실제 데이터 이용허락·공개 배포 권한·호스팅 로그 정책·접근권한은 배포 전 확인해야 합니다.

## 테스트

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
python quick_test.py
# 앱 실행 후, 시스템 Chromium이 있을 때 실제 브라우저 테스트
CHROMIUM_PATH=/usr/bin/chromium python tests/browser_smoke.py
# Chromium이 없다면 승인된 환경에서 설치 후 실행 경로를 지정하세요.
```

`tests/`는 실제 모델 계약·원문 근거·입력 검증·가이드 답변만 전달·상담사 제외·보고서 일치·세션 격리·변조 모델 거부·연구 집계 분모를 검증합니다. Streamlit AppTest로 UI 동작을, Playwright로 실제 다운로드·모바일·다른 브라우저의 접근 차단을 검증합니다. 브라우저 산출물은 `test-results/`에 생성되며 가상 사례만 사용하고 Git에서 제외합니다.

## 배포 준비

`Dockerfile`은 Python 3.12 단일 Streamlit 서버와 상태 확인을 구성합니다. 현재 환경에서는 `Dockerfile.offline` 이미지 빌드, 비root 컨테이너의 실제 2모드 추론, 직접 입력 UI 분석 및 상태 확인이 통과했습니다. 앱 HTTP/WebSocket은 같은 호스트를 사용하며 별도 프론트/API CORS 설정이 없습니다. CORS·XSRF 보호를 끄지 마세요.

```bash
# 인터넷이 제공되는 Docker 환경에서 일반 빌드; 현재 작업은 오프라인 이미지 빌드·비root 컨테이너의 모델 추론·UI·상태 확인을 검증
# private-model-directory/model.pkl 은 제공된 신뢰된 모델이며 공개 배포 권한 확인 필요
# 컨테이너 UID 10001이 읽을 수 있는 파일 권한을 설정하세요.
docker build -t rhope .
docker run --rm -p 8501:8501 \
  --mount type=bind,src=/absolute/private-model-directory,dst=/models,readonly \
  rhope
```

허가된 private 서버/컨테이너 호스팅에서 TLS와 WebSocket 지원을 구성하세요. 리버스 프록시 예시는 `docs/nginx.conf.example`에 있습니다. 호스팅은 모델 2.9MB와 Python 과학 연산 라이브러리를 포함할 수 있어야 하며 최소 1GB 메모리 권장(실제 부하는 별도 측정 필요). 서버 재시작 후 모델은 다시 로드하고 사용자 기록은 복원하지 않습니다. 내부 준비 상태는 `/_stcore/health` 응답과 가상 예시의 실제 모델 분석을 모두 확인하세요. 도메인·계정·모델 공개 권한이 확보되지 않아 **외부 배포 URL은 아직 없습니다**.

현재 클라우드의 Docker 빌드 내부 DNS/프록시 연결은 실패했습니다. 대신 호스트에서 TLS·패키지 체크섬 검증을 유지해 wheel을 다운로드하고 SHA-256을 다시 검증하는 오프라인 빌드 파일을 제공했습니다. `.wheelhouse/`는 공개 Git에서 제외합니다. 생성한 wheel은 Python 3.12/Linux x86_64용이며 다른 플랫폼에서는 해당 플랫폼에 맞게 준비해야 합니다.

```bash
bash scripts/prepare_wheels.sh
# 이 환경에서는 Docker CLI 캐시의 쓰기 가능한 경로가 필요합니다.
DOCKER_CONFIG=/workspace/.cache/rhope/docker docker build -f Dockerfile.offline -t rhope:local .
```

Streamlit Community Cloud도 후보지만 공개 Git에 모델을 넣지 마세요. private 모델 제공 및 이용허락을 해결하지 못하면 연결 필요 상태만 보이며 완성된 모델 시연 배포로 볼 수 없습니다.

## 후속 작업·팀 역할

- 데이터·연구: Training 확보, 공식 라벨 가이드·원본 데이터셋명·라이선스 확인, ID 중복 검증, Training 집계 및 반복 회기 편향 검토.
- 모델: 자유 글 별도 전문가 라벨 평가, 오탐·미탐 검토, 동일 분할의 재학습 비교. 현재 저성능 항목도 공개합니다.
- UI: 실제 한국어 사용자 접근성 검토, 필요하면 PDF 보고서 추가.
- 통합·배포: 허가된 모델 호스팅, TLS·WebSocket·로그 정책·공개 권한 확인, 외부 URL의 3모드 시연 재검증.

10분 발표 동선과 파일별 변경·수락 기준 검증 기록은 `docs/IMPLEMENTATION.md`를 참고하세요.
