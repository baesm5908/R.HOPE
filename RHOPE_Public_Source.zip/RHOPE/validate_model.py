"""Re-evaluate the supplied model on private Validation without editing metrics.json."""
import argparse
import json
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
from sklearn.metrics import precision_recall_fscore_support
from analyzer import load_model
from train_model import read_data
from prepare_data import extract


def validate(archive, output):
    private = Path('data/validation.jsonl.gz')
    stats = extract(archive, private)
    rows = read_data(private)
    model = load_model()
    X = model['vectorizer'].transform([r['text'] for r in rows])
    supplied = json.loads(Path('artifacts/metrics.json').read_text(encoding='utf-8'))
    scores = []
    for original in supplied['labels']:
        key = original['signal']
        indices = [i for i, row in enumerate(rows) if row[key] is not None]
        truth = np.array([rows[i][key] for i in indices])
        pred = (model['models'][key].predict_proba(X[indices])[:, 1] >= model['threshold']).astype(int)
        p, r, f1, _ = precision_recall_fscore_support(truth, pred, average='binary', zero_division=0)
        actual = {**original, 'validated_rows': len(indices), 'positive': int(truth.sum()),
                  'precision': round(float(p), 4), 'recall': round(float(r), 4), 'f1': round(float(f1), 4)}
        actual['matches_supplied_metrics'] = all(actual[k] == original[k] for k in ('validated_rows', 'positive', 'precision', 'recall', 'f1'))
        scores.append(actual)
    result = {'validated_at': datetime.now(timezone.utc).isoformat(), 'scope': supplied['validation_scope'],
              'stats': dict(stats), 'labels': scores,
              'all_match': all(s['matches_supplied_metrics'] for s in scores)}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Re-evaluated model labels:', len(scores), 'all match:', result['all_match'])
    if not result['all_match']:
        raise SystemExit('Re-evaluation differs; inspect local anonymous result, do not overwrite supplied metrics.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--validation', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('artifacts/validation_check.json'))
    args = parser.parse_args()
    validate(args.validation, args.output)
